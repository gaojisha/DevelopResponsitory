package videotest.gjs.com.videotest.TestFileDownload.util;

import android.util.Log;

/**
 * <pre>
 *     author  : gaojisha
 *     e-mail  : gaojisha@feinno.com
 *     time    : 2018/07/05
 *     desc    : 必须说明该类的作用
 *     version : 1.0
 * </pre>
 */
public class LOG {

    private final String TAG = "logutil";

    public static final void error(String tag,String errorInfo){
        Log.e(tag, errorInfo);
    }

    public static final void debug(String tag,String errorInfo){
        Log.d(tag, errorInfo);
    }

}
