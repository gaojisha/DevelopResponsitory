package videotest.gjs.com.videotest.TestFileDownload;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.zhaojian.xuyan.AppApplication;
import com.zhaojian.xuyan.R;
import com.zhaojian.xuyan.controller.util.FileUtil;
import com.zhaojian.xuyan.controller.util.LOG;
import com.zhaojian.xuyan.controller.util.ToastUtil;
import com.zhaojian.xuyan.module.minePage.DownLoadListActivity;
import com.zhaojian.xuyan.module.minePage.DownLoadShowActivity;
import com.zhaojian.xuyan.module.xiaozhibo.zjui.play.PlayScreenActivity;

import java.io.File;

import videotest.gjs.com.videotest.TestFileDownload.util.LOG;

/**
 * Created by jiaqiugui on 12/6/18.
 */

public class MyDownLoadTab1Adapter extends BaseAdapter {

    private JSONArray mJsonArray;
    private Context mContext;
    private JSONArray mCheckList;
    private Handler handler;


    public void setData(JSONArray jsonArray) {
        mJsonArray = jsonArray;
        notifyDataSetChanged();
    }

    private int isShow = 0, pos = 0;


    public int getIsShow() {
        return isShow;
    }

    public void setIsShow(int isShow) {
        this.isShow = isShow;
    }

    public MyDownLoadTab1Adapter(JSONArray mJsonArray, Context mContext, JSONArray mCheckLists) {
        this.mJsonArray = mJsonArray;
        this.mContext = mContext;
        this.mCheckList = mCheckLists;
    }

    @Override
    public int getCount() {
        return null != mJsonArray ? mJsonArray.size() : 0;
    }

    @Override
    public Object getItem(int position) {
        return mJsonArray.getJSONObject(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final ViewHolder mHolder;
        if (convertView == null) {
            mHolder = new ViewHolder();
            convertView = LayoutInflater.from(mContext).inflate(R.layout.zj_download_item_layout, null);
            mHolder.mCheck = (CheckBox) convertView.findViewById(R.id.downLoad_checkbox);
            mHolder.mTitle = (TextView) convertView.findViewById(R.id.download_title);
            mHolder.mState = (TextView) convertView.findViewById(R.id.download_orver_state);
            mHolder.mSize = (TextView) convertView.findViewById(R.id.download_orver_size);
            mHolder.mImg = (ImageView) convertView.findViewById(R.id.download_img);
            mHolder.mOverLayout = (LinearLayout) convertView.findViewById(R.id.download_orver_layout);
            mHolder.mWeiLayout = (RelativeLayout) convertView.findViewById(R.id.downLoad_wei_layout);
            mHolder.mProgressBar = (ProgressBar) convertView.findViewById(R.id.downLoad_progress);
            mHolder.mPause = (ImageView) convertView.findViewById(R.id.download_pause);
            mHolder.mPgTxt = (TextView) convertView.findViewById(R.id.download_pg_txt);
            mHolder.mLayout = (RelativeLayout) convertView.findViewById(R.id.download_layout);
            mHolder.mWeiLayout2 = (LinearLayout) convertView.findViewById(R.id.weiload_album_layout);
            mHolder.mWeiLayout3 = (RelativeLayout) convertView.findViewById(R.id.weiload_class_layout);
            convertView.setTag(mHolder);
        } else {
            mHolder = (ViewHolder) convertView.getTag();
        }
        mHolder.mCheck.setVisibility(pos == isShow ? View.GONE : View.VISIBLE);
        mHolder.mWeiLayout.setVisibility(View.GONE);
        mHolder.mOverLayout.setVisibility(View.VISIBLE);
        mHolder.mWeiLayout2.setVisibility(View.GONE);
        mHolder.mWeiLayout3.setVisibility(View.GONE);
        //0：专辑    1：话题   2：系列话题
        if (mJsonArray.getJSONObject(position).getString("ids").equals("1")) {
            mHolder.mTitle.setText(mJsonArray.getJSONObject(position).getString("className"));
            Glide.with(mContext).load(mJsonArray.getJSONObject(position).getString("classImg"))
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .placeholder(R.drawable.zj_img_empty).error(R.drawable.zj_img_empty)
                    .centerCrop()
                    .into(mHolder.mImg);
            double downloadSize = Long.parseLong(mJsonArray.getJSONObject(position).getString("loadSize")) / 1024f / 1024;
            mHolder.mSize.setText(((float) (Math.round(downloadSize * 100)) / 100) + "M");
            mHolder.mState.setText(pos == Integer.valueOf(mJsonArray.getJSONObject(position).getString("isWatch")) ? R.string.vedio_yi : R.string.vedio_yi2);
            mHolder.mState.setTextColor(pos == Integer.valueOf(mJsonArray.getJSONObject(position).getString("isWatch"))
                    ? mContext.getResources().getColor(R.color.zj_main_bd) : mContext.getResources().getColor(R.color.zj_gray_7f));
        } else {
            mHolder.mTitle.setText(mJsonArray.getJSONObject(position).getString("albumName"));
            Glide.with(mContext).load(mJsonArray.getJSONObject(position).getString("albumImg"))
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .placeholder(R.drawable.zj_img_empty).error(R.drawable.zj_img_empty)
                    .centerCrop()
                    .into(mHolder.mImg);
            mHolder.mState.setTextColor(mContext.getResources().getColor(R.color.zj_gray_7f));
            mHolder.mState.setText("共" + mJsonArray.getJSONObject(position).getString("albumNum") + "节");
            mHolder.mSize.setText("已下载" + mJsonArray.getJSONObject(position).getString("loadNum") + "节");
        }


        setItemSelect(mHolder, mCheckList.contains(mJsonArray.getJSONObject(position)));
        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mHolder.mCheck.isShown()) {
                    if (mCheckList.contains(mJsonArray.getJSONObject(position))) {
                        //如果图片已经选中，就取消选中
                        mCheckList.remove(mJsonArray.getJSONObject(position));
                        setItemSelect(mHolder, false);
                    } else {
                        mCheckList.add(mJsonArray.getJSONObject(position));
                        setItemSelect(mHolder, true);
                    }
                    notifyDataSetChanged();
                } else {//无
                    if (mJsonArray.getJSONObject(position).getString("ids").equals("1")) {
                        String URL = mJsonArray.getJSONObject(position).getString("localPath").replaceAll(" ", "");
                        LOG.debug("jia_down",URL+"\n"+mJsonArray.getJSONObject(position).getString("localPath"));
                        Intent mIntent = new Intent(mContext, DownLoadShowActivity.class);
                        mIntent.setFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);
                        mIntent.putExtra("url",URL);
                        mIntent.putExtra("id", mJsonArray.getJSONObject(position).getString("id"));
                        mIntent.putExtra("className", mJsonArray.getJSONObject(position).getString("className"));
                        mIntent.putExtra("time", mJsonArray.getJSONObject(position).getString("watchPg"));//到播放器开始播放的时间点
                        mContext.startActivity(mIntent);
                    } else {
                        Intent mIntent = new Intent(mContext, DownLoadListActivity.class);
                        mIntent.putExtra("id", mJsonArray.getJSONObject(position).getString("albumId"));
                        mContext.startActivity(mIntent);
                    }
                }

            }
        });
        return convertView;
    }

    class ViewHolder {
        CheckBox mCheck;
        TextView mTitle, mState, mSize, mPgTxt, mStart;
        ImageView mImg, mPause;
        LinearLayout mOverLayout, mWeiLayout2;
        RelativeLayout mWeiLayout, mLayout, mWeiLayout3;
        ProgressBar mProgressBar;

    }

    /**
     * 设置图片选中和未选中的效果
     */
    private void setItemSelect(ViewHolder holder, boolean isSelect) {
        if (isSelect) {
            holder.mCheck.setBackgroundResource(R.drawable.zj_unseleced);
        } else {
            holder.mCheck.setBackgroundResource(R.drawable.zj_selected);
        }
    }

    /**
     * 添加当前的条目
     */
    public void addAllSelected() {
        try {
            for (int i = 0; i < mJsonArray.size(); i++) {
                if (!mCheckList.contains(mJsonArray.getJSONObject(i))) {
                    mCheckList.add(mJsonArray.getJSONObject(i));
                }
            }
        } catch (Exception e) {

            LOG.debug("StudentManagerAdapter", e.getMessage().toString());
        }
    }

    public void selectAllItem(boolean isSelect) {
        //全选==取消全选
        if (isSelect) {
            addAllSelected();
        } else {
            mCheckList.clear();
        }
        notifyDataSetChanged();
    }
}
