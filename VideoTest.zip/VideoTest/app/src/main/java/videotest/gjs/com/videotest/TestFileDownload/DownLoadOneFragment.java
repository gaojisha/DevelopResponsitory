//package videotest.gjs.com.videotest.TestFileDownload;
//
//import android.annotation.SuppressLint;
//import android.content.Intent;
//import android.os.Bundle;
//import android.os.Environment;
//import android.os.Handler;
//import android.os.Message;
//import android.support.annotation.Nullable;
//import android.support.v4.app.Fragment;
//import android.support.v4.widget.SwipeRefreshLayout;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.AdapterView;
//import android.widget.CheckBox;
//import android.widget.CompoundButton;
//import android.widget.ImageView;
//import android.widget.LinearLayout;
//import android.widget.ListView;
//import android.widget.RelativeLayout;
//import android.widget.TextView;
//
//import com.alibaba.fastjson.JSONArray;
//import com.zhaojian.xuyan.R;
//import com.zhaojian.xuyan.controller.db.DbLoadVdManager;
//import com.zhaojian.xuyan.controller.enjoycrop.utils.FileUtils;
//import com.zhaojian.xuyan.controller.event.EventMessage;
//import com.zhaojian.xuyan.controller.util.LOG;
//import com.zhaojian.xuyan.controller.util.SystemMemoryUtil;
//import com.zhaojian.xuyan.controller.util.ToastUtil;
//import com.zhaojian.xuyan.controller.view.RefreshLayout;
//import com.zhaojian.xuyan.module.minePage.DownLoadShowActivity;
//import com.zhaojian.xuyan.module.minePage.adapter.MyDownLoadAdapter;
//import com.zhaojian.xuyan.module.minePage.adapter.MyDownLoadTab1Adapter;
//
//import java.io.File;
//import java.util.ArrayList;
//import java.util.List;
//
//import butterknife.BindView;
//import butterknife.ButterKnife;
//import butterknife.OnClick;
//import de.greenrobot.event.EventBus;
//
//import static com.umeng.commonsdk.stateless.UMSLEnvelopeBuild.mContext;
//import static com.zhaojian.xuyan.controller.enjoycrop.utils.FileUtils.DelFilePhoto;
//import static cz.msebera.android.httpclient.client.methods.RequestBuilder.delete;
//
//
///**
// * @author 作者：jiaqiugui
// * @date 创建时间：13/12/17
// * @className 类名：OrderHuatiFragment
// * @Description 类描述  我的下载==已下载
// * @update 修改时间：
// */
//
//public class DownLoadOneFragment extends Fragment implements SwipeRefreshLayout.OnRefreshListener, CompoundButton.OnCheckedChangeListener {
//
//    private View rootView;
//
//    @BindView(R.id.vedio_refresh)
//    RefreshLayout mRefresh;
//    @BindView(R.id.vedio_lv)
//    ListView mLv;
//    @BindView(R.id.empty_layout)
//    RelativeLayout mEmptyLayout;
//    @BindView(R.id.empty_txt)
//    TextView mEmptyTxt;
//    @BindView(R.id.empty_img)
//    ImageView mEmptyImg;
//    @BindView(R.id.vedio_de_layout)
//    LinearLayout mDeleteLayout;
//    @BindView(R.id.memory_size_layout)
//    LinearLayout mSizeLayout;
//    @BindView(R.id.vedio_delete_view1)
//    View mView1;
//    @BindView(R.id.delete_all_check)
//    CheckBox mCheck;
//    @BindView(R.id.curmory_size)
//    TextView mAllSize;
//    @BindView(R.id.curmory_size2)
//    TextView mKeyongSize;
//
//    private MyDownLoadTab1Adapter mAdapter;
//    private JSONArray mJsonArray, mCheckList;
//    public int showDataTab1 = 0, pos = 0;
//
//
//    @Nullable
//    @Override
//    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//
//        if (null == rootView) {
//
//            rootView = inflater.inflate(R.layout.zj_vedio_layout, container, false);
//            ButterKnife.bind(this, rootView);
//        }
//
//        return rootView;
//    }
//
//    @Override
//    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
//        super.onActivityCreated(savedInstanceState);
//        initView();
//
//    }
//
//    private void initView() {
//        mView1.setVisibility(View.VISIBLE);
//        mSizeLayout.setVisibility(View.VISIBLE);
//        mAllSize.setText(SystemMemoryUtil.getInternalToatalSpace(getActivity()) + ",");
//        mKeyongSize.setText(SystemMemoryUtil.getAvailableInternalMemorySize(getActivity()));
//        mJsonArray = new JSONArray();
//        mCheckList = new JSONArray();
//        mEmptyImg.setImageResource(R.drawable.zj_none_load_vedio);
//        mEmptyTxt.setText("您还没有下载视频哦~");
//
//        mRefresh.setColorSchemeResources(R.color.zj_color_bule2,
//                R.color.zj_color_bule,
//                R.color.zj_color_bule2,
//                R.color.zj_color_bule3);
//        mRefresh.setOnRefreshListener(this);
//
//        mJsonArray = DbLoadVdManager.getInstance(getActivity()).getloadVdList("1");
//
//        mAdapter = new MyDownLoadTab1Adapter(mJsonArray, getActivity(), mCheckList);
//        mLv.setAdapter(mAdapter);
//        showDataTab1 = mAdapter.getIsShow();
//
//
//        mCheck.setOnCheckedChangeListener(this);
//
//
//        mEmptyLayout.setVisibility(mJsonArray.size() > 0 ? View.GONE : View.VISIBLE);
//        mRefresh.setVisibility(mJsonArray.size() > 0 ? View.VISIBLE : View.GONE);
//
//    }
//
//    @OnClick({R.id.delete_txt})
//    public void onClick(View view) {
//        switch (view.getId()) {
//            case R.id.delete_txt:
//                List<String> mList = new ArrayList<>();
//                try {
//                    if (mCheckList.size() > 0) {
//                        for (int i = 0; i < mCheckList.size(); i++) {
//                            mList.add(mCheckList.getJSONObject(i).getString("diff_id"));
//                            String mUrl = mCheckList.getJSONObject(i).getString("localPath");
//                            FileUtils.deleteFile(mUrl, true);
//                            LOG.debug("jia_delete", mUrl);
//                        }
//                        DbLoadVdManager.getInstance(getActivity()).deleteLoadData(mList);
//                        ToastUtil.makeSuccessText("删除成功");
//
//                        mJsonArray = DbLoadVdManager.getInstance(getActivity()).getloadVdList("1");
//                        mAdapter.setData(mJsonArray);
//
//                        mEmptyLayout.setVisibility(mJsonArray.size() > 0 ? View.GONE : View.VISIBLE);
//                        mRefresh.setVisibility(mJsonArray.size() > 0 ? View.VISIBLE : View.GONE);
//
//                        EventBus.getDefault().postSticky(EventMessage.SUCESSES);
//
//                    } else {
//                        ToastUtil.makeSuccessText("请选择要删除的视频");
//                    }
//                } catch (Exception e) {
//                    e.printStackTrace();
//                    LOG.debug(getActivity().getClass().getSimpleName(), "==" + e.toString());
//                }
//                break;
//        }
//
//    }
//
//    @Override
//    public void onRefresh() {
//        mRefresh.postDelayed(new Runnable() {
//
//            @Override
//            public void run() {
//                // 更新数据
//                // 更新完后调用该方法结束刷新
//                mJsonArray = DbLoadVdManager.getInstance(getActivity()).getloadVdList("1");
//                LOG.debug("jia_vedio", mJsonArray.toString());
//                mAdapter.setData(mJsonArray);
//                mRefresh.setRefreshing(false);
//            }
//        }, 1000);
//    }
//
//    //是否显示选中框
//    public void setTab1Show(int i) {
//        if (pos == 0) {
//            mCheckList.clear();
//        }
//        mDeleteLayout.setVisibility(pos == i ? View.GONE : View.VISIBLE);
//        mSizeLayout.setVisibility(pos == i ? View.VISIBLE : View.GONE);
//        mAdapter.setIsShow(i);
//        mAdapter.notifyDataSetChanged();
//
//        showDataTab1 = mAdapter.getIsShow();
//    }
//
//    //刷新数据
//    public void setOnRefresh() {
//        mJsonArray = DbLoadVdManager.getInstance(getActivity()).getloadVdList("1");
//        mAdapter.setData(mJsonArray);
//
//        mEmptyLayout.setVisibility(mJsonArray.size() > 0 ? View.GONE : View.VISIBLE);
//        mRefresh.setVisibility(mJsonArray.size() > 0 ? View.VISIBLE : View.GONE);
//
//
//
//    }
//
//
//    @Override
//    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
//        mAdapter.selectAllItem(isChecked);
//    }
//}
