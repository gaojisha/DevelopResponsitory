package videotest.gjs.com.videotest.TestFileDownload;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import java.util.List;

import videotest.gjs.com.videotest.TestFileDownload.util.LOG;

//import static android.R.attr.id;
//import static com.tencent.qalsdk.base.a.cv;
//import static com.zhaojian.xuyan.controller.db.DbLoadVdManager.LoadTable.Diff_Id;
//import static com.zhaojian.xuyan.controller.db.DbLoadVdManager.LoadTable.albumId;
//import static com.zhaojian.xuyan.controller.db.DbLoadVdManager.LoadTable.albumImg;
//import static com.zhaojian.xuyan.controller.db.DbLoadVdManager.LoadTable.albumLoadNum;
//import static com.zhaojian.xuyan.controller.db.DbLoadVdManager.LoadTable.albumName;
//import static com.zhaojian.xuyan.controller.db.DbLoadVdManager.LoadTable.albumNum;
//import static com.zhaojian.xuyan.controller.db.DbLoadVdManager.LoadTable.classID;
//import static com.zhaojian.xuyan.controller.db.DbLoadVdManager.LoadTable.classImg;
//import static com.zhaojian.xuyan.controller.db.DbLoadVdManager.LoadTable.classIsWatch;
//import static com.zhaojian.xuyan.controller.db.DbLoadVdManager.LoadTable.classLoadSize;
//import static com.zhaojian.xuyan.controller.db.DbLoadVdManager.LoadTable.className;
//import static com.zhaojian.xuyan.controller.db.DbLoadVdManager.LoadTable.classUrl;
//import static com.zhaojian.xuyan.controller.db.DbLoadVdManager.LoadTable.classWatchPg;
//import static com.zhaojian.xuyan.controller.db.DbLoadVdManager.LoadTable.classloCalPath;
//import static com.zhaojian.xuyan.controller.db.DbLoadVdManager.LoadTable.isLoad;
//import static com.zhaojian.xuyan.controller.db.DbLoadVdManager.LoadTable.loadDiffId;
//import static com.zhaojian.xuyan.controller.db.DbNewManager.ZjSearchTable.COL_NAME;

/**
 * Created by jiaqiugui on 9/3/18.
 */

public class DbLoadVdManager {
    private static final String TAG = "DBManager";
    // 数据库名字
    private static final String DB_Vedio_NAME = "zjVedio.db3";
    // 数据库版本号
    private static int DB_VERSION = 1;
    private Context mContext;
    private DatabaseHelper mDBHelper;
    private static DbLoadVdManager mInstance;

    // 创建下载表
    public static class LoadTable {
        public static final String TABLE_Album_NAME = "VedioInfo";// 表名
        public static final String ID = "id";
        public static final String loadDiffId = "ids";//区别是专辑还是话题  1：专辑   0：话题
        public static final String isLoad = "isLoad";//区别是否下载视频   1：已下载   0：下载中
        public static final String Diff_Id = "diffId";//连接值

        public static final String albumId = "albumId";//专辑Id
        public static final String albumName = "albumName";//专辑名字
        public static final String albumImg = "albumImg";//专辑封面
        public static final String albumNum = "albumNum";//专辑总节数
        public static final String albumLoadNum = "loadNum";//专辑已下载节数

        public static final String className = "className";//课程名字
        public static final String classImg = "classImg";//课程封面
        public static final String classID = "classId";// 课程ID
        public static final String classUrl = "classUrl";//观看路径
        public static final String classloCalPath = "classPath";//本地存储路径
        public static final String classLoadSize = "loadSize";//课程下载大小
        public static final String classIsWatch = "isWatch";//是否观看
        public static final String classWatchPg = "watchPg";//观看进度
        public static final String classIsExist = "isExist";//视频是否存在
        public static final String classIsAddMi = "isAddmi";//视频是否加密

//        public static final String classLoadProgress= "proGress";//观看进度


        public static final String CREATE_ALBUM_SQL = "create table if not exists "
                + TABLE_Album_NAME + " (" + ID
                + " integer primary key autoincrement, " + loadDiffId + " varcher ," + isLoad + " varcher ," + Diff_Id + " varcher ,"
                + albumId + " varcher ," + albumName + " varcher ," + albumImg + " varcher, "
                + albumNum + " varcher, " + albumLoadNum + " varcher," + className + " varcher,"
                + classImg + " varcher," + classID + " varcher, " + classUrl + " varcher, " + classloCalPath + " varcher, "
                + classLoadSize + " varcher ," + classIsWatch + " varcher ," + classIsExist + " varcher ," + classIsAddMi + " varcher ,"
                + classWatchPg + " varcher" + ");";
    }

    ;


    private class DatabaseHelper extends SQLiteOpenHelper {

        DatabaseHelper(Context context) {
            super(context, DB_Vedio_NAME, null, DB_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(LoadTable.CREATE_ALBUM_SQL);

        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            LOG.error(getClass().toString(), "Upgrading database from version "
                    + oldVersion + " to " + newVersion
                    + ", which will destroy all old data");
            db.execSQL("DROP TABLE IF EXISTS " + LoadTable.TABLE_Album_NAME);
            onCreate(db);
        }
    }

    /**
     * 初始化
     */
    public static DbLoadVdManager getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new DbLoadVdManager(context);
        }
        return mInstance;
    }

    private DbLoadVdManager(Context context) {
        mContext = context;
        mDBHelper = new DatabaseHelper(mContext);
    }

    private SQLiteDatabase getReadableDatabase() {
        SQLiteDatabase db = this.mDBHelper.getReadableDatabase();
        return db;
    }

    private SQLiteDatabase getWritableDatabase() {
        SQLiteDatabase db = this.mDBHelper.getWritableDatabase();
        return db;
    }

    public void closeDatabase() {
        if (mDBHelper == null) {
            return;
        }
        try {
            mDBHelper.close();
        } catch (Exception e) {
            LOG.error(TAG, "closeDatabase exception:\n" + e.getMessage().toString());
        }
    }

    private void closeCursor(Cursor cur) {
        if (cur == null) {
            return;
        }
        try {
            cur.close();
        } catch (Exception e) {
            LOG.error(TAG, "closeCursor exception:\n" + e.getMessage().toString());
        }
        cur = null;
    }


    public boolean addLoadInfo(JSONObject bean) {
        boolean result = false;
        SQLiteDatabase writeDB = null;
        try {
            writeDB = this.getWritableDatabase();
            // insert the new one
            ContentValues cv = new ContentValues();
            cv.put(LoadTable.loadDiffId, bean.getString("ids"));
            cv.put(LoadTable.isLoad, bean.getString("isLoad"));
            cv.put(LoadTable.Diff_Id, bean.getString("diff_id"));

            cv.put(LoadTable.albumId, bean.getString("albumId"));
            cv.put(LoadTable.albumName, bean.getString("albumName"));
            cv.put(LoadTable.albumImg, bean.getString("albumImg"));
            cv.put(LoadTable.albumNum, bean.getString("albumNum"));
            cv.put(LoadTable.albumLoadNum, bean.getString("loadNum"));

            cv.put(LoadTable.className, bean.getString("className"));
            cv.put(LoadTable.classID, bean.getString("classId"));
            cv.put(LoadTable.classImg, bean.getString("classImg"));
            cv.put(LoadTable.classUrl, bean.getString("classUrl"));
            cv.put(LoadTable.classloCalPath, bean.getString("localPath"));
            cv.put(LoadTable.classLoadSize, bean.getString("loadSize"));
            cv.put(LoadTable.classIsWatch, bean.getString("isWatch"));
            cv.put(LoadTable.classWatchPg, bean.getString("watchPg"));
            cv.put(LoadTable.classIsExist, bean.getString("isExist"));
            cv.put(LoadTable.classIsAddMi, bean.getString("isAddmi"));

            long l = writeDB.insert(LoadTable.TABLE_Album_NAME, null, cv);
            if (l == 0) {
                writeDB.endTransaction();
                result = true;
            }
        } catch (Exception e) {
            LOG.debug(TAG, "add:\n" + e.getMessage().toString());
        } finally {
        }
        return result;
    }


    /**
     * @param
     * @Description 类方法   得到添加的Json
     */
    public JSONObject getJsonData(String ids, String diff_id, String albumId, String albumName, String albumImg, String albumNum, String loadNum
            , String className, String classId, String classImg, String loadSize, String isWatch, String classUrl) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("ids", ids);
        jsonObject.put("isLoad", "0");
        jsonObject.put("diff_id", diff_id);

        jsonObject.put("albumId", albumId);
        jsonObject.put("albumName", albumName);
        jsonObject.put("albumImg", albumImg);
        jsonObject.put("albumNum", albumNum);
        jsonObject.put("loadNum", loadNum);

        jsonObject.put("className", className);
        jsonObject.put("classId", classId);
        jsonObject.put("classImg", classImg);
        jsonObject.put("loadSize", loadSize);
        jsonObject.put("isWatch", isWatch);
        jsonObject.put("watchPg", "0");
        jsonObject.put("classUrl", classUrl);
        jsonObject.put("localPath", "");
        jsonObject.put("isExist", "1");
        jsonObject.put("isAddmi", "0");
        return jsonObject;

    }

    /**
     * 查询所有下载数据
     */
    public JSONArray getVedioAllList() {
        String sqls = "select * from " + LoadTable.TABLE_Album_NAME;
        SQLiteDatabase readDB = null;
        Cursor cursor = null;
        JSONObject productBean = null;
        JSONArray list = new JSONArray();
        try {
            readDB = this.getReadableDatabase();
            cursor = readDB.rawQuery(sqls, null);
            while (cursor.moveToNext()) {
                productBean = new JSONObject();
                productBean.put("id", cursor.getString(cursor.getColumnIndex(LoadTable.ID)));
                productBean.put("ids", cursor.getString(cursor.getColumnIndex(LoadTable.loadDiffId)));
                productBean.put("isLoad", cursor.getString(cursor.getColumnIndex(LoadTable.isLoad)));
                productBean.put("diff_id", cursor.getString(cursor.getColumnIndex(LoadTable.Diff_Id)));
                productBean.put("albumId", cursor.getString(cursor.getColumnIndex(LoadTable.albumId)));
                productBean.put("albumName", cursor.getString(cursor.getColumnIndex(LoadTable.albumName)));
                productBean.put("albumImg", cursor.getString(cursor.getColumnIndex(LoadTable.albumImg)));
                productBean.put("albumNum", cursor.getString(cursor.getColumnIndex(LoadTable.albumNum)));
                productBean.put("loadNum", cursor.getString(cursor.getColumnIndex(LoadTable.albumLoadNum)));

                productBean.put("className", cursor.getString(cursor.getColumnIndex(LoadTable.className)));
                productBean.put("classId", cursor.getString(cursor.getColumnIndex(LoadTable.classID)));
                productBean.put("classImg", cursor.getString(cursor.getColumnIndex(LoadTable.classImg)));
                productBean.put("loadSize", cursor.getString(cursor.getColumnIndex(LoadTable.classLoadSize)));
                productBean.put("isWatch", cursor.getString(cursor.getColumnIndex(LoadTable.classIsWatch)));
                productBean.put("watchPg", cursor.getString(cursor.getColumnIndex(LoadTable.classWatchPg)));
                productBean.put("classUrl", cursor.getString(cursor.getColumnIndex(LoadTable.classUrl)));
                productBean.put("localPath", cursor.getString(cursor.getColumnIndex(LoadTable.classloCalPath)));
                productBean.put("isExist", cursor.getString(cursor.getColumnIndex(LoadTable.classIsExist)));
                productBean.put("isAddmi", cursor.getString(cursor.getColumnIndex(LoadTable.classIsAddMi)));

                list.add(productBean);
            }
        } catch (Exception e) {
            LOG.error(TAG, "get:\n" + e.getMessage().toString());
        } finally {
            closeCursor(cursor);
        }
        return list;
    }

    /**
     * 根据区分是否下载视频  查询数据
     */
    public JSONArray getloadVdList(String id) {
        LOG.debug(TAG, "ID=" + id);
        String sqls = "select * from " + LoadTable.TABLE_Album_NAME + " where (" + LoadTable.isLoad + " = '" + id + "')";

        LOG.error(TAG, "ISLOAD=" + sqls);
        SQLiteDatabase readDB = null;
        Cursor cursor = null;
        JSONArray list = new JSONArray();
        JSONObject productBean;
        try {
            readDB = this.getReadableDatabase();
            cursor = readDB.rawQuery(sqls, null);
            while (cursor.moveToNext()) {
                productBean = new JSONObject();

                productBean.put("id", cursor.getString(cursor.getColumnIndex(LoadTable.ID)));
                productBean.put("ids", cursor.getString(cursor.getColumnIndex(LoadTable.loadDiffId)));
                productBean.put("isLoad", cursor.getString(cursor.getColumnIndex(LoadTable.isLoad)));
                productBean.put("diff_id", cursor.getString(cursor.getColumnIndex(LoadTable.Diff_Id)));
                productBean.put("albumId", cursor.getString(cursor.getColumnIndex(LoadTable.albumId)));
                productBean.put("albumName", cursor.getString(cursor.getColumnIndex(LoadTable.albumName)));
                productBean.put("albumImg", cursor.getString(cursor.getColumnIndex(LoadTable.albumImg)));
                productBean.put("albumNum", cursor.getString(cursor.getColumnIndex(LoadTable.albumNum)));
                productBean.put("loadNum", cursor.getString(cursor.getColumnIndex(LoadTable.albumLoadNum)));

                productBean.put("className", cursor.getString(cursor.getColumnIndex(LoadTable.className)));
                productBean.put("classId", cursor.getString(cursor.getColumnIndex(LoadTable.classID)));
                productBean.put("classImg", cursor.getString(cursor.getColumnIndex(LoadTable.classImg)));
                productBean.put("loadSize", cursor.getString(cursor.getColumnIndex(LoadTable.classLoadSize)));
                productBean.put("isWatch", cursor.getString(cursor.getColumnIndex(LoadTable.classIsWatch)));
                productBean.put("watchPg", cursor.getString(cursor.getColumnIndex(LoadTable.classWatchPg)));
                productBean.put("classUrl", cursor.getString(cursor.getColumnIndex(LoadTable.classUrl)));
                productBean.put("localPath", cursor.getString(cursor.getColumnIndex(LoadTable.classloCalPath)));
                productBean.put("isExist", cursor.getString(cursor.getColumnIndex(LoadTable.classIsExist)));
                productBean.put("isAddmi", cursor.getString(cursor.getColumnIndex(LoadTable.classIsAddMi)));

                list.add(productBean);
            }
        } catch (Exception e) {
            LOG.error(TAG, "get:\n" + e.getMessage().toString());
        } finally {
            closeCursor(cursor);
        }
        return list;
    }


    public JSONArray getloadVdClassList(String id, String aId) {
        LOG.debug(TAG, "ID=" + id);
        String sqls = "select * from " + LoadTable.TABLE_Album_NAME
                + " where ( 1=1 ";
        if (null != id) {
            sqls += " and " + LoadTable.albumId + " like '%" + id + "%' ";
        }
        if (null != aId) {
            sqls += " and " + LoadTable.isLoad + " like '%" + aId + "%' ";
        }
        sqls += " )";
//        String sqls = "select * from " + LoadTable.TABLE_Album_NAME + " where (" + albumId + " = '" + id + "')";

        LOG.error(TAG, "getloadVdClassList=" + sqls);
        SQLiteDatabase readDB = null;
        Cursor cursor = null;
        JSONArray list = new JSONArray();
        JSONObject productBean;
        try {
            readDB = this.getReadableDatabase();
            cursor = readDB.rawQuery(sqls, null);
            while (cursor.moveToNext()) {
                productBean = new JSONObject();

                productBean.put("id", cursor.getString(cursor.getColumnIndex(LoadTable.ID)));
                productBean.put("ids", cursor.getString(cursor.getColumnIndex(LoadTable.loadDiffId)));
                productBean.put("isLoad", cursor.getString(cursor.getColumnIndex(LoadTable.isLoad)));
                productBean.put("diff_id", cursor.getString(cursor.getColumnIndex(LoadTable.Diff_Id)));
                productBean.put("albumId", cursor.getString(cursor.getColumnIndex(LoadTable.albumId)));
                productBean.put("albumName", cursor.getString(cursor.getColumnIndex(LoadTable.albumName)));
                productBean.put("albumImg", cursor.getString(cursor.getColumnIndex(LoadTable.albumImg)));
                productBean.put("albumNum", cursor.getString(cursor.getColumnIndex(LoadTable.albumNum)));
                productBean.put("loadNum", cursor.getString(cursor.getColumnIndex(LoadTable.albumLoadNum)));

                productBean.put("className", cursor.getString(cursor.getColumnIndex(LoadTable.className)));
                productBean.put("classId", cursor.getString(cursor.getColumnIndex(LoadTable.classID)));
                productBean.put("classImg", cursor.getString(cursor.getColumnIndex(LoadTable.classImg)));
                productBean.put("loadSize", cursor.getString(cursor.getColumnIndex(LoadTable.classLoadSize)));
                productBean.put("isWatch", cursor.getString(cursor.getColumnIndex(LoadTable.classIsWatch)));
                productBean.put("watchPg", cursor.getString(cursor.getColumnIndex(LoadTable.classWatchPg)));
                productBean.put("classUrl", cursor.getString(cursor.getColumnIndex(LoadTable.classUrl)));
                productBean.put("localPath", cursor.getString(cursor.getColumnIndex(LoadTable.classloCalPath)));
                productBean.put("isExist", cursor.getString(cursor.getColumnIndex(LoadTable.classIsExist)));
                productBean.put("isAddmi", cursor.getString(cursor.getColumnIndex(LoadTable.classIsAddMi)));
                list.add(productBean);
            }
        } catch (Exception e) {
            LOG.error(TAG, "get:\n" + e.getMessage().toString());
        } finally {
            closeCursor(cursor);
        }
        return list;
    }

    /**
     * 方法说明： 根据Id修改是否观看视频时间
     *
     * @param id
     * @param isShow
     */
    public void updateLoadIsWatch(String id, String isShow) {
        SQLiteDatabase writeDB = null;
        try {
            writeDB = this.getWritableDatabase();
            writeDB.beginTransaction();
            String sqls = "update " + LoadTable.TABLE_Album_NAME + " set "
                    + LoadTable.classIsWatch + " = ' " + isShow
                    + " ' " + " where ( " + LoadTable.ID + " =' " + id
                    + " ')";
            writeDB.execSQL(sqls);
            writeDB.setTransactionSuccessful();
            writeDB.endTransaction();
        } catch (Exception e) {
            LOG.debug(TAG, "delete:\n" + e.getMessage().toString());
        } finally {
        }
    }

    public void updateLoadIsAddmi(String id, String isShow) {
        SQLiteDatabase writeDB = null;
        try {
            writeDB = this.getWritableDatabase();
            writeDB.beginTransaction();
            String sqls = "update " + LoadTable.TABLE_Album_NAME + " set "
                    + LoadTable.classIsAddMi + " = ' " + isShow
                    + " ' " + " where ( " + LoadTable.ID + " =' " + id
                    + " ')";
            writeDB.execSQL(sqls);
            writeDB.setTransactionSuccessful();
            writeDB.endTransaction();
        } catch (Exception e) {
            LOG.debug(TAG, "delete:\n" + e.getMessage().toString());
        } finally {
        }
    }

    public void updateisLoad(String id, String isShow) {
        SQLiteDatabase writeDB = null;
        try {
            writeDB = this.getWritableDatabase();
            writeDB.beginTransaction();
            String sqls = "update " + LoadTable.TABLE_Album_NAME + " set "
                    + LoadTable.isLoad + " = ' " + isShow
                    + " ' " + " where ( " + LoadTable.Diff_Id + " =' " + id
                    + " ')";
            writeDB.execSQL(sqls);
            writeDB.setTransactionSuccessful();
            writeDB.endTransaction();
        } catch (Exception e) {
            LOG.debug(TAG, "delete:\n" + e.getMessage().toString());
        } finally {
        }
    }

    public void updateDiffId(String id, String isShow) {
        SQLiteDatabase writeDB = null;
        try {
            writeDB = this.getWritableDatabase();
            writeDB.beginTransaction();
            String sqls = "update " + LoadTable.TABLE_Album_NAME + " set "
                    + LoadTable.Diff_Id + " = ' " + isShow
                    + " ' " + " where ( " + LoadTable.ID + " =' " + id
                    + " ')";
            writeDB.execSQL(sqls);
            writeDB.setTransactionSuccessful();
            writeDB.endTransaction();
        } catch (Exception e) {
            LOG.debug(TAG, "delete:\n" + e.getMessage().toString());
        } finally {
        }
    }
    public void updateFileSize(String id, String isShow) {
        SQLiteDatabase writeDB = null;
        try {
            writeDB = this.getWritableDatabase();
            writeDB.beginTransaction();
            String sqls = "update " + LoadTable.TABLE_Album_NAME + " set "
                    + LoadTable.classLoadSize + " = ' " + isShow
                    + " ' " + " where ( " + LoadTable.ID + " =' " + id
                    + " ')";
            writeDB.execSQL(sqls);
            writeDB.setTransactionSuccessful();
            writeDB.endTransaction();
        } catch (Exception e) {
            LOG.debug(TAG, "delete:\n" + e.getMessage().toString());
        } finally {
        }
    }

    public void updateLookTime(String id, String isShow) {
        SQLiteDatabase writeDB = null;
        try {
            writeDB = this.getWritableDatabase();
            writeDB.beginTransaction();
            String sqls = "update " + LoadTable.TABLE_Album_NAME + " set "
                    + LoadTable.classWatchPg + " = ' " + isShow
                    + " ' " + " where ( " + LoadTable.ID + " =' " + id
                    + " ')";
            writeDB.execSQL(sqls);
            writeDB.setTransactionSuccessful();
            writeDB.endTransaction();
        } catch (Exception e) {
            LOG.debug(TAG, "delete:\n" + e.getMessage().toString());
        } finally {
        }
    }

    public void updateLoadUrl(String id, String isShow) {
        SQLiteDatabase writeDB = null;
        try {
            writeDB = this.getWritableDatabase();
            writeDB.beginTransaction();
            String sqls = "update " + LoadTable.TABLE_Album_NAME + " set "
                    + LoadTable.classloCalPath + " = ' " + isShow
                    + " ' " + " where ( " + LoadTable.Diff_Id + " =' " + id
                    + " ')";
            writeDB.execSQL(sqls);
            writeDB.setTransactionSuccessful();
            writeDB.endTransaction();
        } catch (Exception e) {
            LOG.debug(TAG, "delete:\n" + e.getMessage().toString());
        } finally {
        }
    }

    /**
     * 删除多条信息
     */
    public void deleteLoadData(List<String> ids) {
        SQLiteDatabase writeDB = null;
        try {
            String sql = "delete from " + LoadTable.TABLE_Album_NAME;
            writeDB = this.getWritableDatabase();
            writeDB.beginTransaction();
            for (int i = 0; i < ids.size(); i++) {
                String sql2 = " where (" + LoadTable.Diff_Id + " = '" + ids.get(i) + "')";
                writeDB.execSQL(sql + sql2);
            }
            writeDB.setTransactionSuccessful();
            writeDB.endTransaction();
        } catch (Exception e) {
            LOG.error(TAG, "delete:\n" + e.getMessage().toString());
        } finally {
        }
    }


    /**
     * 清空数据库
     */
    public void clear() {
        SQLiteDatabase writeDB = null;
        try {
            writeDB = this.getWritableDatabase();
            writeDB.beginTransaction();
            String sql = "delete from " + LoadTable.TABLE_Album_NAME
                    + " where (1=1)";
            writeDB.execSQL(sql);
            writeDB.setTransactionSuccessful();
            writeDB.endTransaction();
        } catch (Exception e) {
            LOG.error(TAG, "clear:\n" + e.getMessage().toString());
        } finally {
        }
    }


}
