//package videotest.gjs.com.videotest.TestFileDownload;
//
//import android.app.Activity;
//import android.graphics.Color;
//import android.os.Bundle;
//import android.os.PersistableBundle;
//import android.support.annotation.Nullable;
//import android.support.v4.app.Fragment;
//import android.support.v4.app.FragmentPagerAdapter;
//import android.support.v4.view.ViewPager;
//import android.view.View;
//import android.widget.TextView;
//
//import com.alibaba.fastjson.JSONArray;
//import com.alibaba.fastjson.JSONObject;
//import com.zhaojian.xuyan.R;
//import com.zhaojian.xuyan.controller.base.BaseActivity;
//import com.zhaojian.xuyan.controller.event.EventMessage;
//import com.zhaojian.xuyan.controller.util.LOG;
//import com.zhaojian.xuyan.module.minePage.fragment.DownLoadOneFragment;
//import com.zhaojian.xuyan.module.minePage.fragment.DownLoadTwoFragment;
//
//import org.greenrobot.eventbus.EventBus;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import butterknife.BindView;
//import butterknife.ButterKnife;
//import butterknife.OnClick;
//import de.greenrobot.event.EventBus;
//import videotest.gjs.com.videotest.R;
//import videotest.gjs.com.videotest.TestFileDownload.util.LOG;
//
//
///**
// * @author 作者：jiaqiugui
// * @date 创建时间：16/12/17
// * @className 类名：DownLoadActivity
// * @Description 类描述  下载页面
// * @update 修改时间：
// */
//
//public class DownLoadActivity extends Activity {
//
//    @BindView(R.id.download_viewpager)
//    ViewPager msgVp;
//
//    //已下载
//    @BindView(R.id.focus_view_1)
//    TextView textfocus1;
//    @BindView(R.id.focus_1)
//    View mFocusView1;
//
//    //未下载
//    @BindView(R.id.focus_view_2)
//    TextView textfocus2;
//    @BindView(R.id.focus_2)
//    View mFocusView2;
//
//    private FragmentPagerAdapter mAdapter;
//    private List<Fragment> mFragments;
//    private DownLoadOneFragment downLoadOneFragment;
//    private DownLoadTwoFragment downLoadTwoFragment;
//
//    private final int FLAG_TAG0 = 0;
//    private final int FLAG_TAG1 = 1;
//
//    private int mCurPage = 0;
//
//    @Override
//    public void onCreate(@Nullable Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.zj_download_layout);
//        ButterKnife.bind(DownLoadActivity.this);
//        EventBus.getDefault().register(DownLoadActivity.this);
//        setTitleDisplay(true);
//        setTitle(R.string.personal_download_title);
//        setMenuText("编辑");
//        setMenuColor();
//        setMenuViewOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                int pos;
//                if (mCurPage == 0) {
//                    pos = (downLoadOneFragment.showDataTab1 == 0) ? 1 : 0;
//                    downLoadOneFragment.setTab1Show(pos);
//                } else {
//                    pos = (downLoadTwoFragment.showDataTab2 == 0) ? 1 : 0;
//                    downLoadTwoFragment.setTab2Show(pos);
//                }
//                LOG.debug(DownLoadActivity.class.getSimpleName(), "===pos=" + pos);
//                if (pos == 1) {
//                    setMenuText("取消");
//                } else {
//                    setMenuText("编辑");
//                }
//            }
//        });
//        swicthPageUi();
//    }
//
//
//    //页面切换开始
//    private void swicthPageUi() {
//        mFragments = new ArrayList<>();
//        downLoadOneFragment = new DownLoadOneFragment();
//        downLoadTwoFragment = new DownLoadTwoFragment();
//        mFragments.add(downLoadOneFragment);
//        mFragments.add(downLoadTwoFragment);
//
////        msgVp.setOffscreenPageLimit(1);
//        mAdapter = new FragmentPagerAdapter(getSupportFragmentManager()) {
//            @Override
//            public Fragment getItem(int position) {
//
//                return mFragments.get(position);
//            }
//
//            @Override
//            public int getCount() {
//                return mFragments.size();
//            }
//        };
//
//        msgVp.setAdapter(mAdapter);
//        msgVp.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
//
//            @Override
//            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
//
//            }
//
//            @Override
//            public void onPageSelected(int position) {
//                LOG.debug(DownLoadActivity.class.getSimpleName(), "===position=page" + position);
//                setMenuText("编辑");
//                downLoadTwoFragment.setTab2Show(0);
//                downLoadOneFragment.setTab1Show(0);
//                mCurPage = position;
//                selectTab(position);
//            }
//
//            @Override
//            public void onPageScrollStateChanged(int state) {
//
//            }
//        });
//        msgVp.setCurrentItem(mCurPage);
//    }
//
//    private void selectTab(int i) {
//
//        mFocusView1.setVisibility(i == FLAG_TAG0 ? View.VISIBLE : View.INVISIBLE);
//        mFocusView2.setVisibility(i == FLAG_TAG1 ? View.VISIBLE : View.INVISIBLE);
//        textfocus1.setTextColor(i == FLAG_TAG0 ? Color.parseColor("#d62223") : Color.parseColor("#333333"));
//        textfocus2.setTextColor(i == FLAG_TAG1 ? Color.parseColor("#d62223") : Color.parseColor("#333333"));
//        msgVp.setCurrentItem(i);
//    }
//
//    public void onEventMainThread(EventMessage event) {
//        switch (event) {
//            case SUCESSES:
//                setMenuText("编辑");
//                if (mCurPage == 0) {
//                    downLoadOneFragment.setTab1Show(0);
//                } else {
//                    downLoadTwoFragment.setTab2Show(0);
//                }
//                break;
//            case DELETE:
//                downLoadOneFragment.setOnRefresh();
//                break;
//        }
//    }
//
//    @OnClick({R.id.download_tab1, R.id.download_tab2})
//    public void onClick(View v) {
//        switch (v.getId()) {
//            case R.id.download_tab1:
//                selectTab(FLAG_TAG0);
//                break;
//            case R.id.download_tab2:
//                selectTab(FLAG_TAG1);
//                break;
//        }
//    }
//
//    @Override
//    protected void onDestroy() {
//        super.onDestroy();
//        EventBus.getDefault().unregister(DownLoadActivity.this);
//    }
//}
