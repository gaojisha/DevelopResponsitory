//package videotest.gjs.com.videotest.TestFileDownload;
//
//import android.annotation.SuppressLint;
//import android.app.DownloadManager;
//import android.content.Intent;
//import android.os.Bundle;
//import android.os.Environment;
//import android.os.Handler;
//import android.os.Message;
//import android.support.annotation.Nullable;
//import android.support.v4.app.Fragment;
//import android.support.v4.widget.SwipeRefreshLayout;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.AdapterView;
//import android.widget.CheckBox;
//import android.widget.CompoundButton;
//import android.widget.ImageView;
//import android.widget.LinearLayout;
//import android.widget.ListView;
//import android.widget.RelativeLayout;
//import android.widget.TextView;
//
//import com.alibaba.fastjson.JSONArray;
////import com.alibaba.fastjson.JSONObject;
////import com.zhaojian.xuyan.R;
////import com.zhaojian.xuyan.controller.db.DbLoadVdManager;
////import com.zhaojian.xuyan.controller.event.EventMessage;
////import com.zhaojian.xuyan.controller.services.ypServer.YpServiceManager;
////import com.zhaojian.xuyan.controller.services.ypServer.YpServiceUtil;
////import com.zhaojian.xuyan.controller.util.LOG;
////import com.zhaojian.xuyan.controller.util.SystemMemoryUtil;
////import com.zhaojian.xuyan.controller.util.ToastUtil;
////import com.zhaojian.xuyan.controller.view.RefreshLayout;
////import com.zhaojian.xuyan.module.minePage.adapter.MyDownLoadAdapter;
//
//import org.wlf.filedownloader.DownloadFileInfo;
//import org.wlf.filedownloader.FileDownloader;
//import org.wlf.filedownloader.listener.OnDeleteDownloadFileListener;
//import org.wlf.filedownloader.listener.OnDeleteDownloadFilesListener;
//import org.wlf.filedownloader.listener.OnDownloadFileChangeListener;
//
//import java.io.File;
//import java.util.ArrayList;
//import java.util.List;
//
////import butterknife.BindView;
////import butterknife.ButterKnife;
////import butterknife.OnClick;
////import de.greenrobot.event.EventBus;
//import videotest.gjs.com.videotest.R;
//import videotest.gjs.com.videotest.TestFileDownload.util.LOG;
//
////import static com.umeng.commonsdk.stateless.UMSLEnvelopeBuild.mContext;
//
//
///**
// * @author 作者：jiaqiugui
// * @date 创建时间：13/12/17
// * @className 类名：OrderHuatiFragment
// * @Description 类描述  我的下载==未下载
// * @update 修改时间：
// */
//
//public class DownLoadTwoFragment extends Fragment implements SwipeRefreshLayout.OnRefreshListener, CompoundButton.OnCheckedChangeListener {
//
//    private View rootView;
//
//    @BindView(R.id.vedio_refresh)
//    RefreshLayout mRefresh;
//    @BindView(R.id.vedio_lv)
//    ListView mLv;
//    @BindView(R.id.empty_layout)
//    RelativeLayout mEmptyLayout;
//    @BindView(R.id.empty_txt)
//    TextView mEmptyTxt;
//    @BindView(R.id.empty_img)
//    ImageView mEmptyImg;
//
//    @BindView(R.id.vedio_de_layout)
//    LinearLayout mDeleteLayout;
//    @BindView(R.id.memory_size_layout)
//    LinearLayout mSizeLayout;
//    @BindView(R.id.vedio_delete_view1)
//    View mView1;
//    @BindView(R.id.delete_all_check)
//    CheckBox mCheck;
//    @BindView(R.id.curmory_size)
//    TextView mAllSize;
//    @BindView(R.id.curmory_size2)
//    TextView mKeyongSize;
//
//    private MyDownLoadAdapter mAdapter;
//    private JSONArray mJsonArray, mCheckArray;
//    private List<DownloadFileInfo> mInfoList, mCheckList;
//
//    public int showDataTab2 = 0, pos = 0;
//    private int loadPos;
//
//
//    @SuppressLint("HandlerLeak")
//    private Handler mHandler = new Handler() {
//        @Override
//        public void handleMessage(Message msg) {
//            super.handleMessage(msg);
//            switch (msg.what) {
//                case 300://点击
//                    try {
//                        loadPos = (Integer) msg.obj;
//                        int loading = Integer.valueOf(mJsonArray.getJSONObject(loadPos).getString("state"));
//                        LOG.debug("jia_vedio", "pos=" + mInfoList.get(loadPos).getUrl() + "\n" + loading);
//                        if (loading == 0) {
//                            FileDownloader.start(mInfoList.get(loadPos).getUrl());// 开启单个下载任务
//                        } else {
//                            FileDownloader.pause(mInfoList.get(loadPos).getUrl());// 暂停单个下载任务
//                        }
//                    } catch (Exception e) {
//                        LOG.debug("jia_vedio", e.toString());
//                    }
////                    loading = (loading == 0) ? 1 : 0;
//                    break;
//            }
//        }
//    };
//
//
//    @Nullable
//    @Override
//    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//
//        if (null == rootView) {
//
//            rootView = inflater.inflate(R.layout.zj_vedio_layout, container, false);
//            ButterKnife.bind(DownLoadTwoFragment.this, rootView);
//        }
//
//        return rootView;
//    }
//
//    @Override
//    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
//        super.onActivityCreated(savedInstanceState);
//        initView();
//    }
//
//    private void initView() {
//        mEmptyTxt.setText("您还没有下载的视频哦~");
//        mEmptyImg.setImageResource(R.drawable.zj_none_load_vedio);
//        mView1.setVisibility(View.VISIBLE);
//        mSizeLayout.setVisibility(View.VISIBLE);
//        mAllSize.setText(SystemMemoryUtil.getInternalToatalSpace(getActivity()) + ",");
//        mKeyongSize.setText(SystemMemoryUtil.getAvailableInternalMemorySize(getActivity()));
//        mJsonArray = new JSONArray();
//        mCheckArray = new JSONArray();
//        mInfoList = new ArrayList<>();
//        mCheckList = new ArrayList<>();
//        mRefresh.setColorSchemeResources(R.color.zj_color_bule2,
//                R.color.zj_color_bule,
//                R.color.zj_color_bule2,
//                R.color.zj_color_bule3);
//        mRefresh.setOnRefreshListener(this);
//
//        mJsonArray = DbLoadVdManager.getInstance(getActivity()).getloadVdList("0");
//        mInfoList = FileDownloader.getDownloadFiles();
//
//
//        mAdapter = new MyDownLoadAdapter(mInfoList, getActivity(), mCheckList, mJsonArray, mCheckArray, mHandler);
//        mLv.setAdapter(mAdapter);
//
//        FileDownloader.registerDownloadStatusListener(mAdapter);//下载所需监听
////        FileDownloader.registerDownloadFileChangeListener(mOnDownloadFileChangeListener);//文件更新监听
//
//
//        mCheck.setOnCheckedChangeListener(this);
//
//
//        mEmptyLayout.setVisibility(mInfoList.size() > 0 ? View.GONE : View.VISIBLE);
//        mRefresh.setVisibility(mInfoList.size() > 0 ? View.VISIBLE : View.GONE);
//
//    }
//
//    @OnClick({R.id.delete_txt})
//    public void onClick(View view) {
//        switch (view.getId()) {
//            case R.id.delete_txt:
//                List<String> mList = new ArrayList<>();
//                List<String> mListNew = new ArrayList<>();
//                if (mCheckList.size() > 0) {
//                    for (int i = 0; i < mCheckList.size(); i++) {
//                        mList.add(mCheckList.get(i).getUrl());
//                        mListNew.add(String.valueOf(mCheckList.get(i).getId()));
//                    }
//                    initDelete(mList, mListNew);
//
//                } else {
//                    ToastUtil.makeFailText("请选择要删除的视频");
//                }
//                break;
//        }
//    }
//
//    private void initDelete(List<String> mList, List<String> mListNew) {
//        DbLoadVdManager.getInstance(getActivity()).deleteLoadData(mListNew);
//        FileDownloader.delete(mList, true, new OnDeleteDownloadFilesListener() {
//            @Override
//            public void onDeleteDownloadFilesPrepared(List<DownloadFileInfo> downloadFilesNeedDelete) {
//                LOG.debug(getActivity().getClass().getSimpleName(), "onDeleteDownloadFileSuccess 准备" + "准备");
//            }
//
//            @Override
//            public void onDeletingDownloadFiles(List<DownloadFileInfo> downloadFilesNeedDelete, List<DownloadFileInfo> downloadFilesDeleted, List<DownloadFileInfo> downloadFilesSkip, DownloadFileInfo downloadFileDeleting) {
//                LOG.debug(getActivity().getClass().getSimpleName(), "onDeleteDownloadFileSuccess 失败回调" + "失败");
//            }
//
//            @Override
//            public void onDeleteDownloadFilesCompleted(List<DownloadFileInfo> downloadFilesNeedDelete, List<DownloadFileInfo> downloadFilesDeleted) {
//                LOG.debug(getActivity().getClass().getSimpleName(), "onDeleteDownloadFileSuccess 成功回调" + "成功");
//                ToastUtil.makeSuccessText("删除成功");
//                mJsonArray = DbLoadVdManager.getInstance(getActivity()).getloadVdList("0");
//                mInfoList = FileDownloader.getDownloadFiles();
//                mAdapter.setData(mInfoList, mJsonArray);
//                showDataTab2 = 0;
//                EventBus.getDefault().postSticky(EventMessage.SUCESSES);
//
//
//                mEmptyLayout.setVisibility(mInfoList.size() > 0 ? View.GONE : View.VISIBLE);
//                mRefresh.setVisibility(mInfoList.size() > 0 ? View.VISIBLE : View.GONE);
//
//                LOG.debug("jia_vedio", mJsonArray.toString() + "\n" + mInfoList.size());
//            }
//        });
//
//    }
//
//    @Override
//    public void onRefresh() {
//        mRefresh.postDelayed(new Runnable() {
//
//            @Override
//            public void run() {
//                // 更新数据
//                // 更新完后调用该方法结束刷新
//                mJsonArray = DbLoadVdManager.getInstance(getActivity()).getloadVdList("0");
//                mInfoList = FileDownloader.getDownloadFiles();
//                mAdapter.setData(mInfoList, mJsonArray);
//
//                mEmptyLayout.setVisibility(mInfoList.size() > 0 ? View.GONE : View.VISIBLE);
//                mRefresh.setVisibility(mInfoList.size() > 0 ? View.VISIBLE : View.GONE);
//                LOG.debug("jia_vedio", mJsonArray.toString() + "\n" + mInfoList.size());
//                mRefresh.setRefreshing(false);
//            }
//        }, 1000);
//    }
//
//    public void setTab2Show(int i) {
//        if (pos == 0) {
//            mCheckList.clear();
//            mCheckArray.clear();
//        }
//
//        mDeleteLayout.setVisibility(pos == i ? View.GONE : View.VISIBLE);
//        mSizeLayout.setVisibility(pos == i ? View.VISIBLE : View.GONE);
//        mAdapter.setIsShow(i);
//        mAdapter.notifyDataSetChanged();
//
//        showDataTab2 = mAdapter.getIsShow();
//    }
//
//    @Override
//    public void onDestroy() {
//        super.onDestroy();
//        // pause all downloads
////        FileDownloader.pauseAll();
//        // unregisterDownloadStatusListener
//        FileDownloader.unregisterDownloadStatusListener(mAdapter);
//    }
//
//    @Override
//    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
//        mAdapter.selectAllItem(isChecked);
//    }
//}
