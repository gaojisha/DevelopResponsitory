package videotest.gjs.com.videotest.permission;

/**
 * <pre>
 *     author  : gaojisha
 *     e-mail  : gaojisha@feinno.com
 *     time    : 2018/05/28
 *     desc    : 必须说明该类的作用
 *     version : 1.0
 * </pre>
 */

public interface PermissionResult {
    void success();
    void fail();
}