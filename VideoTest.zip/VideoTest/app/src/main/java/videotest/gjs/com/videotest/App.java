package videotest.gjs.com.videotest;

import android.Manifest;
import android.app.Application;
import android.widget.Toast;

import java.util.List;

import videotest.gjs.com.videotest.permission.PermissionUtil;

/**
 * <pre>
 *     author  : gaojisha
 *     e-mail  : gaojisha@feinno.com
 *     time    : 2018/07/03
 *     desc    : 必须说明该类的作用
 *     version : 1.0
 * </pre>
 */
public class App extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
