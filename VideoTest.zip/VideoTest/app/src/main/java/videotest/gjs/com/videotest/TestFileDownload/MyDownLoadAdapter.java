package videotest.gjs.com.videotest.TestFileDownload;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSONArray;
//import com.bumptech.glide.Glide;
//import com.bumptech.glide.load.engine.DiskCacheStrategy;
//import com.zhaojian.xuyan.R;
//import com.zhaojian.xuyan.controller.db.DbLoadVdManager;
//import com.zhaojian.xuyan.controller.event.EventMessage;
//import com.zhaojian.xuyan.controller.util.ArithUtil;
//import com.zhaojian.xuyan.controller.util.LOG;
//import com.zhaojian.xuyan.module.message.conversation.view.utils.TimeUtil;
//import com.zhaojian.xuyan.module.minePage.DownLoadListActivity;
//import com.zhaojian.xuyan.module.minePage.DownLoadShowActivity;

import org.greenrobot.eventbus.EventBus;
import org.wlf.filedownloader.DownloadFileInfo;
import org.wlf.filedownloader.FileDownloader;
import org.wlf.filedownloader.base.Status;
import org.wlf.filedownloader.listener.OnDeleteDownloadFileListener;
import org.wlf.filedownloader.listener.OnFileDownloadStatusListener;
import org.wlf.filedownloader.listener.OnRetryableFileDownloadStatusListener;

import java.io.File;
import java.util.List;
//import java.util.concurrent.TimeUnit;

//import de.greenrobot.event.EventBus;
import videotest.gjs.com.videotest.R;
import videotest.gjs.com.videotest.TestFileDownload.util.LOG;

//import static com.tencent.qalsdk.base.a.T;
//import static com.tencent.qalsdk.base.a.co;
//import static com.zhaojian.xuyan.R.drawable.position;

/**
 * Created by jiaqiugui on 12/6/18.
 */

public class MyDownLoadAdapter extends BaseAdapter implements OnRetryableFileDownloadStatusListener {
    private static final String TAG = "jia_down";

    private List<DownloadFileInfo> mInfoList, mCheckList;
    private JSONArray mInfoArray, mCheckArray;
    private Context mContext;
    private Handler handler;

    private int isShow = 0, pos = 0;
    private float downLoadSpeed = 0;
    private String mError = "";

    public void setData(List<DownloadFileInfo> mInfo, JSONArray mInArray) {
        this.mInfoList = mInfo;
        this.mInfoArray = mInArray;
        notifyDataSetChanged();
    }


    public int getIsShow() {
        return isShow;
    }

    public void setIsShow(int isShow) {
        this.isShow = isShow;
    }

    public MyDownLoadAdapter(List<DownloadFileInfo> mJsonArray, Context mContext
            , List<DownloadFileInfo> mCheckLists, JSONArray infoArray, JSONArray checkArray, Handler mHandler) {
        this.mInfoList = mJsonArray;
        this.mContext = mContext;
        this.mCheckList = mCheckLists;
        this.mInfoArray = infoArray;
        this.mCheckArray = checkArray;
        this.handler = mHandler;
    }

    @Override
    public int getCount() {
        return null != mInfoList ? mInfoList.size() : 0;
    }

    @Override
    public Object getItem(int position) {
        return mInfoList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final ViewHolder mHolder;
        if (convertView == null) {
            mHolder = new ViewHolder();
            convertView = LayoutInflater.from(mContext).inflate(R.layout.zj_download_item_layout, null);
            mHolder.mCheck = (CheckBox) convertView.findViewById(R.id.downLoad_checkbox);
            mHolder.mTitle = (TextView) convertView.findViewById(R.id.download_title);
            mHolder.mState = (TextView) convertView.findViewById(R.id.download_orver_state);
            mHolder.mSize = (TextView) convertView.findViewById(R.id.download_orver_size);
            mHolder.mImg = (ImageView) convertView.findViewById(R.id.download_img);
            mHolder.mOverLayout = (LinearLayout) convertView.findViewById(R.id.download_orver_layout);
            mHolder.mWeiLayout = (RelativeLayout) convertView.findViewById(R.id.downLoad_wei_layout);
            mHolder.mProgressBar = (ProgressBar) convertView.findViewById(R.id.downLoad_progress);
            mHolder.mPause = (ImageView) convertView.findViewById(R.id.download_pause);
            mHolder.mPgTxt = (TextView) convertView.findViewById(R.id.download_pg_txt);
            mHolder.mLayout = (RelativeLayout) convertView.findViewById(R.id.download_layout);
            mHolder.mWeiLayout2 = (LinearLayout) convertView.findViewById(R.id.weiload_album_layout);
            mHolder.mWeiLayout3 = (RelativeLayout) convertView.findViewById(R.id.weiload_class_layout);
            mHolder.mLoadState = (TextView) convertView.findViewById(R.id.download_vedio_state);
            convertView.setTag(mHolder);
        } else {
            mHolder = (ViewHolder) convertView.getTag();
        }
        mHolder.mCheck.setVisibility(pos == isShow ? View.GONE : View.VISIBLE);
        mHolder.mWeiLayout.setVisibility(View.VISIBLE);
        mHolder.mOverLayout.setVisibility(View.GONE);
        mHolder.mWeiLayout2.setVisibility(View.GONE);
        mHolder.mWeiLayout3.setVisibility(View.VISIBLE);
        for (int i = 0; i < mInfoArray.size(); i++) {
            if (mInfoList.get(position).getUrl().equals(mInfoArray.getJSONObject(i).getString("classUrl"))) {
                mHolder.mTitle.setText(mInfoArray.getJSONObject(i).getString("className"));
//                Glide.with(mContext).load(mInfoArray.getJSONObject(i).getString("classImg"))
//                        .diskCacheStrategy(DiskCacheStrategy.ALL)
//                        .placeholder(R.drawable.zj_img_empty).error(R.drawable.zj_img_empty)
//                        .centerCrop()
//                        .into(mHolder.mImg);
            }
        }

        // download progress
        int totalSize = (int) mInfoList.get(position).getFileSizeLong();
        int downloaded = (int) mInfoList.get(position).getDownloadedSizeLong();
        double rate = (double) totalSize / Integer.MAX_VALUE;
        if (rate > 1.0) {
            totalSize = Integer.MAX_VALUE;
            downloaded = (int) (downloaded / rate);
        }
        mHolder.mProgressBar.setMax(totalSize);
        mHolder.mProgressBar.setProgress(downloaded);

        // file size
        double downloadSize = mInfoList.get(position).getDownloadedSizeLong() / 1024f / 1024;
        double fileSize = mInfoList.get(position).getFileSizeLong() / 1024f / 1024;
        String sizes=((float) (Math.round(downloadSize * 100)) / 100) + "M/" + ((float) (Math.round(fileSize * 100)) / 100) + "M";
        mHolder.mPgTxt.setText(sizes);

//        LOG.debug(TAG, "SIZE=" + mInfoList.get(position).getDownloadedSizeLong() + "\n" + mInfoList.get(position).getFileSizeLong());
//        mHolder.mPgTxt.setText(ArithUtil.getKBDataSize(mInfoList.get(position).getDownloadedSizeLong()) + "/" + ArithUtil.getKBDataSize(mInfoList.get(position).getFileSizeLong()));

        // download speed and remain times
        String speed = ((float) (Math.round(downLoadSpeed * 100)) / 100) + "KB/s";
        mHolder.mLoadState.setTag(speed);
        mHolder.mLoadState.setText(speed);
        switch (mInfoList.get(position).getStatus()) {
            // download file status:unknown
            case Status.DOWNLOAD_STATUS_UNKNOWN:
                mError = "无法下载，请删除后重新下载";
                break;
            // download file status:retrying
            case Status.DOWNLOAD_STATUS_RETRYING:
                mError = "重试：重连资源";
                break;
            // download file status:preparing
            case Status.DOWNLOAD_STATUS_PREPARING:
                mError = "正在获取资源";
                break;
            // download file status:prepared
            case Status.DOWNLOAD_STATUS_PREPARED:
                mError = "已连接资源";
                break;
            // download file status:paused
            case Status.DOWNLOAD_STATUS_PAUSED:
                mInfoArray.getJSONObject(position).put("state","0");
                mHolder.mPause.setImageDrawable(mContext.getResources().getDrawable(R.drawable.zj_load_start));
                mHolder.mPause.setVisibility(View.VISIBLE);
                mError = "已暂停";
                break;
            // download file status:downloading
            case Status.DOWNLOAD_STATUS_DOWNLOADING:
                mInfoArray.getJSONObject(position).put("state","1");
                mHolder.mPause.setImageDrawable(mContext.getResources().getDrawable(R.drawable.zj_load_pause));
                mHolder.mPause.setVisibility(View.VISIBLE);
                if (mHolder.mLoadState.getTag() != null) {
                    mError = (String) mHolder.mLoadState.getTag();
                } else {
                    mError = "正在下载";
                }
                break;
            // download file status:error
            case Status.DOWNLOAD_STATUS_ERROR:
                mError = "下载出错，请删除后重新下载";
                break;
            // download file status:waiting
            case Status.DOWNLOAD_STATUS_WAITING:
                mError = "等待下载";
                break;
            // download file status:completed
            case Status.DOWNLOAD_STATUS_COMPLETED:
                mError = "已下载完成";
                break;
            // download file status:file not exist
            case Status.DOWNLOAD_STATUS_FILE_NOT_EXIST:
                mError = "文件不存在";
                break;
        }

        mHolder.mLoadState.setText(mError);


        setItemSelect(mHolder, mCheckList.contains(mInfoList.get(position)));
        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mHolder.mCheck.isShown()) {
                    if (mCheckList.contains(mInfoList.get(position))) {
                        //如果图片已经选中，就取消选中
                        mCheckList.remove(mInfoList.get(position));
                        setItemSelect(mHolder, false);
                    } else {
                        mCheckList.add(mInfoList.get(position));
                        setItemSelect(mHolder, true);
                    }
                    notifyDataSetChanged();
                } else {//无
                    handler.sendMessage(handler.obtainMessage(300, position));//开始
                }

            }
        });
        return convertView;
    }

    /**
     * update show
     */
    public void updateShow() {
        mInfoList = FileDownloader.getDownloadFiles();
        notifyDataSetChanged();
    }

    @Override
    public void onFileDownloadStatusRetrying(DownloadFileInfo downloadFileInfo, int retryTimes) {
//        // 正在重试下载（如果你配置了重试次数，当一旦下载失败时会尝试重试下载），retryTimes是当前第几次重试
        LOG.debug(TAG, "onFileDownloadStatusRetrying=" + downloadFileInfo);
        updateShow();

    }

    @Override
    public void onFileDownloadStatusWaiting(DownloadFileInfo downloadFileInfo) {
//        // 等待下载（等待其它任务执行完成，或者FileDownloader在忙别的操作）
        LOG.debug(TAG, "onFileDownloadStatusWaiting=" + downloadFileInfo);
        updateShow();

    }

    @Override
    public void onFileDownloadStatusPreparing(DownloadFileInfo downloadFileInfo) {
//        // 准备中（即，正在连接资源）
        LOG.debug(TAG, "onFileDownloadStatusPreparing=" + downloadFileInfo);
        updateShow();

    }

    @Override
    public void onFileDownloadStatusPrepared(DownloadFileInfo downloadFileInfo) {
//        // 已准备好（即，已经连接到了资源）
        LOG.debug(TAG, "onFileDownloadStatusPrepared=" + downloadFileInfo);
        updateShow();

    }

    @Override
    public void onFileDownloadStatusDownloading(DownloadFileInfo downloadFileInfo, float downloadSpeed, long remainingTime) {
//        // 正在下载，downloadSpeed为当前下载速度，单位KB/s，remainingTime为预估的剩余时间，单位秒
        LOG.debug(TAG, "onFileDownloadStatusDownloading=" + downloadFileInfo
                + "\n" + downloadFileInfo.getTempFilePath() + File.separator + downloadFileInfo.getFileName() + "\n" + FileDownloader.getDownloadDir());
        downLoadSpeed = downloadSpeed;
//        reMainIngTime = remainingTime;
        updateShow();

    }

    @Override
    public void onFileDownloadStatusPaused(DownloadFileInfo downloadFileInfo) {
////        // 下载完成（整个文件已经全部下载完成）
        LOG.debug(TAG, "onFileDownloadStatusPaused=" + downloadFileInfo);

        updateShow();
    }

    @Override
    public void onFileDownloadStatusCompleted(DownloadFileInfo downloadFileInfo) {
        LOG.debug(TAG, "onFileDownloadStatusCompleted=" + downloadFileInfo.getId());
//        EventBus.getDefault().postSticky(EventMessage.DELETE);
        DbLoadVdManager.getInstance(mContext).updateisLoad(String.valueOf(downloadFileInfo.getId()),"1");
        DbLoadVdManager.getInstance(mContext).updateLoadUrl(String.valueOf(downloadFileInfo.getId()), FileDownloader.getDownloadDir() + File.separator + downloadFileInfo.getFileName());
        FileDownloader.delete(downloadFileInfo.getUrl(), false, new OnDeleteDownloadFileListener() {
            @Override
            public void onDeleteDownloadFileSuccess(DownloadFileInfo downloadFileDeleted) {
                LOG.debug(TAG, "onDeleteDownloadFileSuccess 成功回调，单个删除" + downloadFileDeleted.getFileName()
                        + "成功");
                updateShow();
            }

            @Override
            public void onDeleteDownloadFilePrepared(DownloadFileInfo downloadFileNeedDelete) {
                if (downloadFileNeedDelete != null) {
                    LOG.debug(TAG, "准备中" + downloadFileNeedDelete.getFileName());
                }
            }

            @Override
            public void onDeleteDownloadFileFailed(DownloadFileInfo downloadFileInfo,
                                                   DeleteDownloadFileFailReason failReason) {
                if (downloadFileInfo != null) {
                    LOG.debug(TAG, downloadFileInfo.getFileName() + "删除失败=" + failReason.toString());
                }
            }
        });

    }

    @Override
    public void onFileDownloadStatusFailed(String url, DownloadFileInfo downloadFileInfo, FileDownloadStatusFailReason failReason) {

        // 下载失败了，详细查看失败原因failReason，有些失败原因你可能必须关心
        mError = "下载出错";
        if (failReason != null) {
            if (FileDownloadStatusFailReason.TYPE_NETWORK_DENIED.equals(failReason.getType())) {
                mError += "(请检查网络)";
            } else if (FileDownloadStatusFailReason.TYPE_URL_ILLEGAL.equals(failReason.getType())) {
                mError += "(Url不合法)";
            } else if (FileDownloadStatusFailReason.TYPE_NETWORK_TIMEOUT.equals(failReason.getType())) {
                mError += "(网络超时)";
            } else if (FileDownloadStatusFailReason.TYPE_STORAGE_SPACE_IS_FULL.equals(failReason.getType())) {
                mError += "(存储空间已满)";
            } else if (FileDownloadStatusFailReason.TYPE_STORAGE_SPACE_CAN_NOT_WRITE.equals(failReason.getType())) {
                mError += "(存储空间不可写)";
            } else if (FileDownloadStatusFailReason.TYPE_FILE_NOT_DETECT.equals(failReason.getType())) {
                mError += "(文件没有被探测到)";
            } else if (FileDownloadStatusFailReason.TYPE_BAD_HTTP_RESPONSE_CODE.equals(failReason.getType())) {
                mError += "(Http 返回错误)";
            } else if (FileDownloadStatusFailReason.TYPE_HTTP_FILE_NOT_EXIST.equals(failReason.getType())) {
                mError += "(Http请求文件不存在)";
            } else if (FileDownloadStatusFailReason.TYPE_SAVE_FILE_NOT_EXIST.equals(failReason.getType())) {
                mError += "(保存文件不存在)";
            }else{
                mError += "(请删除后，重新下载)";
            }
        }
        // 查看详细异常信息
        Throwable failCause = failReason.getCause();// 或：failReason.getOriginalCause()

        // 查看异常描述信息
        String failMsg = failReason.getMessage();// 或：failReason.getOriginalCause().getMessage()
        LOG.debug(TAG, "onFileDownloadStatusFailed=" + mError + "failCause=" + failCause + "\n" + failMsg);
        updateShow();
    }

    class ViewHolder {
        CheckBox mCheck;
        TextView mTitle, mState, mSize, mPgTxt, mStart, mLoadState;
        ImageView mImg, mPause;
        LinearLayout mOverLayout, mWeiLayout2;
        RelativeLayout mWeiLayout, mLayout, mWeiLayout3;
        ProgressBar mProgressBar;

    }

    /**
     * 设置图片选中和未选中的效果
     */
    private void setItemSelect(ViewHolder holder, boolean isSelect) {
        if (isSelect) {
            holder.mCheck.setBackgroundResource(R.drawable.zj_unseleced);
        } else {
            holder.mCheck.setBackgroundResource(R.drawable.zj_selected);
        }
    }

    /**
     * 添加当前的条目
     */
    public void addAllSelected() {
        try {
            for (int i = 0; i < mInfoList.size(); i++) {
                if (!mCheckList.contains(mInfoList.get(i))) {
                    mCheckList.add(mInfoList.get(i));
                }
            }
        } catch (Exception e) {

            LOG.debug("StudentManagerAdapter", e.getMessage().toString());
        }
    }

    public void selectAllItem(boolean isSelect) {
        //全选==取消全选
        if (isSelect) {
            addAllSelected();
        } else {
            mCheckList.clear();
        }
        notifyDataSetChanged();
    }

}
