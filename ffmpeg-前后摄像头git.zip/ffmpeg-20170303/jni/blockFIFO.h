/*
 * blockFIFO.h
 *
 *  Created on: 2016��5��27��
 *      Author: Administrator
 */

#ifndef BLOCKFIFO_H_
#define BLOCKFIFO_H_
#include "Locker.h"
#include "EnvRuntime.h"

using namespace lkx;

struct Frame {
	unsigned char* data;
	int size;
	long timestamp;
};

class blockFIFO {
	std::list<Frame*> mEmpty;
	std::list<Frame*> mFull;

	Locker mEmptyLocker;
	Locker mFullLocker;
	Semaphore mFullSemo;

	int mRefCount;
	int mAlloced;
	bool mOpened;

	Frame* getListEmpty ();
	void  doWork ();
	virtual void  onFrame (Frame* frame);
	void  clear ();
	void* Entry();
	static void* ThreadMain (void* p) { return ((blockFIFO*)p)->Entry(); }

public:
	blockFIFO();
	virtual ~blockFIFO();

	Frame* getEmpty (int size);
	Frame* getFull ();
	bool isOpened () 	{ return mOpened; }

	void addRef ();
	void release ();

	void addEmpty (Frame* frame);
	void addFull (Frame* frame);

	void open ();
	void close ();
};

#endif /* BLOCKFIFO_H_ */
