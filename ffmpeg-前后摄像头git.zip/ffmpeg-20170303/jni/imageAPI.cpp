/*
 * imageAPI.cpp
 *
 *  Created on: 2016��5��24��
 *      Author: Administrator
 */

#include "imageAPI.h"

typedef int int32;
typedef unsigned int uint32;
typedef unsigned char uint8;
typedef unsigned short uint16;

// C reference code that mimics the YUV assembly.

#define YG 74 /* static_cast<int8>(1.164 * 64 + 0.5) */

#define UB 127 /* min(63,static_cast<int8>(2.018 * 64)) */
#define UG -25 /* static_cast<int8>(-0.391 * 64 - 0.5) */
#define UR 0

#define VB 0
#define VG -52 /* static_cast<int8>(-0.813 * 64 - 0.5) */
#define VR 102 /* static_cast<int8>(1.596 * 64 + 0.5) */

// Bias
#define BB UB * 128 + VB * 128
#define BG UG * 128 + VG * 128
#define BR UR * 128 + VR * 128

#define clamp0(v)	((int32) ((-(v) >> 31) & (v)))

#define clamp255(v)	((int32) ((((255 - (v)) >> 31) | (v)) & 255))

#define Clamp(ret, val)											\
	  macro_par = val;											\
	  macro_val = clamp0(macro_par);							\
	  ret = (uint32)(clamp255(macro_val));

#define YuvPixel(y, u, v, b, g, r)								\
{																\
	y1 = ((int32)(y) - 16) * YG;								\
	Clamp(b, (int32)((u * UB + v * VB) - (BB) + y1) >> 6);		\
	Clamp(g, (int32)((u * UG + v * VG) - (BG) + y1) >> 6);		\
	Clamp(r, (int32)((u * UR + v * VR) - (BR) + y1) >> 6);		\
}

void NV21ToRGB565Row_C(const uint8* src_y,
                       const uint8* vsrc_u,
                       uint8* dst_rgb565,
                       int width) {
  uint8 b0;
  uint8 g0;
  uint8 r0;
  uint8 b1;
  uint8 g1;
  uint8 r1;
  int32 y1;
  int x;
  int macro_val;
  int32 macro_par;

  for (x = 0; x < width - 1; x += 2) {
    YuvPixel(src_y[0], vsrc_u[1], vsrc_u[0], b0, g0, r0);
    YuvPixel(src_y[1], vsrc_u[1], vsrc_u[0], b1, g1, r1);
    b0 = b0 >> 3;
    g0 = g0 >> 2;
    r0 = r0 >> 3;
    b1 = b1 >> 3;
    g1 = g1 >> 2;
    r1 = r1 >> 3;
    * (uint32*)(dst_rgb565) = b0 | (g0 << 5) | (r0 << 11) |
        (b1 << 16) | (g1 << 21) | (r1 << 27);
    src_y += 2;
    vsrc_u += 2;
    dst_rgb565 += 4;  // Advance 2 pixels.
  }
  if (width & 1) {
    YuvPixel(src_y[0], vsrc_u[1], vsrc_u[0], b0, g0, r0);
    b0 = b0 >> 3;
    g0 = g0 >> 2;
    r0 = r0 >> 3;
    *(uint16*)(dst_rgb565) = b0 | (g0 << 5) | (r0 << 11);
  }
}

void cvt_420sp_to_rgb565(int width, int height, const unsigned char *src, unsigned short *dst) {
	unsigned char* c_dst = (unsigned char*) dst;
	int size = width * height;
	int i;
	for (i=0; i<height; i++) {
		NV21ToRGB565Row_C (src + i*width, src + size + i/2*width, c_dst + i * width * 2, width);
	}
}


/*
void cvt_420p_to_rgb565(int width, int height, const unsigned char *src, unsigned short *dst)
{
  int line, col, linewidth;
  int y, u, v, yy, vr, ug, vg, ub;
  int r, g, b;
  const unsigned char *py, *pu, *pv;

  linewidth = width >> 1;
  py = src;
  pu = py + (width * height);
  pv = pu + (width * height) / 4;

  y = *py++;
  yy = y << 8;
  u = *pu - 128;
  ug = 88 * u;
  ub = 454 * u;
  v = *pv - 128;
  vg = 183 * v;
  vr = 359 * v;

  for (line = 0; line < height; line++) {
    for (col = 0; col < width; col++) {
      r = (yy + vr) >> 8;
      g = (yy - ug - vg) >> 8;
      b = (yy + ub ) >> 8;

      if (r < 0) r = 0;
      if (r > 255) r = 255;
      if (g < 0) g = 0;
      if (g > 255) g = 255;
      if (b < 0) b = 0;
      if (b > 255) b = 255;
      *dst++ = (((unsigned short)r>>3)<<11) | (((unsigned short)g>>2)<<5) | (((unsigned short)b>>3)<<0);

      y = *py++;
      yy = y << 8;
      if (col & 1) {
    pu++;
    pv++;

    u = *pu - 128;
    ug = 88 * u;
    ub = 454 * u;
    v = *pv - 128;
    vg = 183 * v;
    vr = 359 * v;
      }
    }
    if ((line & 1) == 0) {
      pu -= linewidth;
      pv -= linewidth;
    }
  }
}*/

/*

void NV21ToRGB565Row_C(const uint8* src_y,
                       const uint8* vsrc_u,
                       uint8* dst_rgb565,
                       int width);

// libyuvapi
// Convert NV21 to RGB565.
int NV21ToRGB565(const uint8* src_y, int src_stride_y,
                 const uint8* src_vu, int src_stride_vu,
                 uint8* dst_rgb565, int dst_stride_rgb565,
                 int width, int height) {
  if (!src_y || !src_vu || !dst_rgb565 ||
      width <= 0 || height == 0) {
    return -1;
  }
  // Negative height means invert the image.
  if (height < 0) {
    height = -height;
    dst_rgb565 = dst_rgb565 + (height - 1) * dst_stride_rgb565;
    dst_stride_rgb565 = -dst_stride_rgb565;
  }
  void (*NV21ToRGB565Row)(const uint8* y_buf,
                          const uint8* src_vu,
                          uint8* rgb_buf,
                          int width) = NV21ToRGB565Row_C;
#if defined(HAS_NV21TORGB565ROW_SSSE3)
  if (TestCpuFlag(kCpuHasSSSE3) && width >= 8) {
    NV21ToRGB565Row = NV21ToRGB565Row_Any_SSSE3;
    if (IS_ALIGNED(width, 8)) {
      NV21ToRGB565Row = NV21ToRGB565Row_SSSE3;
    }
  }
#elif defined(HAS_NV21TORGB565ROW_NEON)
  if (TestCpuFlag(kCpuHasNEON) && width >= 8) {
    NV21ToRGB565Row = NV21ToRGB565Row_Any_NEON;
    if (IS_ALIGNED(width, 8)) {
      NV21ToRGB565Row = NV21ToRGB565Row_NEON;
    }
  }
#endif

  for (int y = 0; y < height; ++y) {
    NV21ToRGB565Row(src_y, src_vu, dst_rgb565, width);
    dst_rgb565 += dst_stride_rgb565;
    src_y += src_stride_y;
    if (y & 1) {
      src_vu += src_stride_vu;
    }
  }
  return 0;
}

void NV21ToRGB565Row_C(const uint8* src_y,
                       const uint8* vsrc_u,
                       uint8* dst_rgb565,
                       int width) {
  uint8 b0;
  uint8 g0;
  uint8 r0;
  uint8 b1;
  uint8 g1;
  uint8 r1;
  for (int x = 0; x < width - 1; x += 2) {
    YuvPixel(src_y[0], vsrc_u[1], vsrc_u[0], &b0, &g0, &r0);
    YuvPixel(src_y[1], vsrc_u[1], vsrc_u[0], &b1, &g1, &r1);
    b0 = b0 >> 3;
    g0 = g0 >> 2;
    r0 = r0 >> 3;
    b1 = b1 >> 3;
    g1 = g1 >> 2;
    r1 = r1 >> 3;
    *reinterpret_cast<uint32*>(dst_rgb565) = b0 | (g0 << 5) | (r0 << 11) |
        (b1 << 16) | (g1 << 21) | (r1 << 27);
    src_y += 2;
    vsrc_u += 2;
    dst_rgb565 += 4;  // Advance 2 pixels.
  }
  if (width & 1) {
    YuvPixel(src_y[0], vsrc_u[1], vsrc_u[0], &b0, &g0, &r0);
    b0 = b0 >> 3;
    g0 = g0 >> 2;
    r0 = r0 >> 3;
    *reinterpret_cast<uint16*>(dst_rgb565) = b0 | (g0 << 5) | (r0 << 11);
  }
}
*/


