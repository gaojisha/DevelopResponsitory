/*
 * Locker.h
 *
 *  Created on: 2015��10��22��
 *      Author: Administrator
 */

#ifndef LOCKER_H_
#define LOCKER_H_

namespace lkx {

class Locker {
public:
	Locker();
	~Locker();

private:
	friend class Lock;
	friend class Semaphore;
	void* mObj;
};

class Lock {
public:
	Lock(Locker* locker);
	~Lock();

private:
	Locker* mLocker;
};

class Semaphore {
public:
	Semaphore ();
	~Semaphore ();
	bool wait (Locker* locker);
	void signal ();

private:
	void* mObj;
};

}

#endif /* LOCKER_H_ */
