/*
 * imageAPI.h
 *
 *  Created on: 2016��5��24��
 *      Author: Administrator
 */

#ifndef IMAGEAPI_H_
#define IMAGEAPI_H_

void cvt_420sp_to_rgb565(int width, int height, const unsigned char *src, unsigned short *dst);

#endif /* IMAGEAPI_H_ */
