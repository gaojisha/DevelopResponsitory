//
// Created by Administrator on 2016/5/24.
//

extern "C" {
	#include "com_feinno_avsdk_ffmpeg_MP4Writer.h"
}
#include <stdio.h>
#include <stdlib.h>
#include "clipNV21.h"
#include "imageAPI.h"
#include "EnvRuntime.h"
#include "main.h"
#include "blockFIFO.h"
#include "AudioFIFO.h"

EvnRuntime gRuntime;
int  mmRorate;
blockFIFO* mFIFO;
blockFIFO* mFIFOAudio;

/**
 * ����ͼƬ�任Ԥ�������ú�getRGB565() ���Է��ع�Ԥ����ͼƬ
 * @param srcw
 * @param srch
 * @param dstw
 * @param dsth
 */
JNIEXPORT void JNICALL Java_com_feinno_avsdk_ffmpeg_MP4Writer_openPreview
  (JNIEnv* env, jobject obj, jint srcw, jint srch, jint dstw, jint dsth, jint rarote) {
	logInt (0);
	mmRorate=rarote;
	if(rarote>0){
			log ("===============��������1111111111111111----");
		}else{
			log ("===============��������000000--------");
		}
	gRuntime.initCache(srcw, srch, dstw, dsth,rarote);
}


/**
 * ��MP4�ļ���Ϊд��
 * @param path          �ļ�·��
 * @param srcw          ԭʼ��Ƶ����
 * @param srch          ԭʼ��Ƶ�߶�
 * @param dstw          ��ȡ����Ƶ����
 * @param dsth          ��ȡ����Ƶ�߶�
 * @param frate         ��Ƶ֡��
 * @return              true-�򿪳ɹ�  false-��ʧ��
 */

extern "C"
JNIEXPORT jboolean JNICALL Java_com_feinno_avsdk_ffmpeg_MP4Writer_openMP4File (JNIEnv* env,
		jobject obj, jstring path,
		jint srcw, jint srch, jint dstw, jint dsth, 						// ͼƬ�ߴ�任
		jint vFrameRate, jint vBitrate, jint vQuality,						// ��Ƶ����
		jint aBitrate, jint aSampleRate, jint aChannels, jint aQuality, jint aRorate) {	// ��Ƶ����

	logInt (0);
	mmRorate=aRorate;
	if(aRorate>0){
		log ("===============��������11111111");
	}else{
		log ("===============��������000000");
	}

	gRuntime.initCache(srcw, srch, dstw, dsth,aRorate);
	gRuntime.initFFMPEG(vFrameRate, vBitrate, vQuality, aBitrate, aSampleRate, aChannels, aQuality);

	if (mFIFO == NULL) {
		mFIFO = new blockFIFO ();
		mFIFO->addRef();
		mFIFO->open();
	}

	if (mFIFOAudio == NULL) {
		mFIFOAudio = new AudioFIFO ();
		mFIFOAudio->addRef();
		mFIFOAudio->open();
	}

	jboolean copy = false;
	const char* str_path = env->GetStringUTFChars(path, &copy);
	bool suc = createMP4File (str_path);
	env->ReleaseStringUTFChars(path, str_path);

	log (suc ? "open suc" : "open failed");
	return suc;
}

extern "C"
JNIEXPORT void JNICALL Java_com_feinno_avsdk_ffmpeg_MP4Writer_closeMP4 (JNIEnv *, jobject, jboolean stopPreview) {
	logInt (0);

	if (mFIFO != NULL) {
		mFIFO->close();
		mFIFO->release();
		mFIFO = NULL;
	}

	if (mFIFOAudio != NULL) {
		mFIFOAudio->close();
		mFIFOAudio->release();
		mFIFOAudio = NULL;
	}

	if (stopPreview) {
		gRuntime.uninit();
	}
	closeMP4 ();
}

extern "C"
JNIEXPORT void JNICALL Java_com_feinno_avsdk_ffmpeg_MP4Writer_closePreview (JNIEnv *, jobject) {
	logInt (0);
	gRuntime.uninit();
}

extern "C"
JNIEXPORT void JNICALL Java_com_feinno_avsdk_ffmpeg_MP4Writer_addVideo (JNIEnv *env,
		jobject obj, jbyteArray arr, jint offset, jint fmt, jint rotate, jlong timestamp) {

	if (!gRuntime.isInited()) {
		logInt (-1);
		return;
	}

	// ��������
	jint size = env->GetArrayLength(arr);
	jbyte* cache = gRuntime.getFullVideoCache(size);
	env->GetByteArrayRegion(arr, offset, size, cache);

	// �ü�ͼƬ
	jbyte* cliped = gRuntime.getClipedVideoCache(gRuntime.mClipImgSize);
	clipTargetRect90 ( (byte*)cache, (byte*)cliped, gRuntime.mSrcW, gRuntime.mSrcH,
			gRuntime.mClipStartW, gRuntime.mClipStartH, gRuntime.mClipW, gRuntime.mClipH);

	//logInt (3);
	if (timestamp <= 0 || mFIFO == NULL || !mFIFO->isOpened()) {		// timestamp = 0 ��Ϊ����û����ɳ�ʼ��
		return;
	}
	Frame* frame = mFIFO->getEmpty(gRuntime.mClipImgSize);
	if (frame != NULL) {
		memcpy (frame->data, cliped, gRuntime.mClipImgSize);
		frame->timestamp = timestamp;
		mFIFO->addFull(frame);
	}
}


/*
 * Class:     com_feinno_avsdk_ffmpeg_MP4Writer
 * Method:    getRGB565
 * Signature: ([S)V
 */
extern "C"
JNIEXPORT jboolean JNICALL Java_com_feinno_avsdk_ffmpeg_MP4Writer_getRGB565 (JNIEnv* env,
		jobject obj, jshortArray arr) {

	if (!gRuntime.isInited()) {
		logInt (-1);
		return false;
	}

	unsigned short* bmp565 = (unsigned short* ) gRuntime.getImage565(gRuntime.m565ImgSize);
	cvt_420sp_to_rgb565 (gRuntime.mDstW, gRuntime.mDstH,
			(unsigned char*) gRuntime.getClipedVideoCache(gRuntime.mClipImgSize), bmp565);

	env->SetShortArrayRegion(arr, 0, gRuntime.m565ImgSize, (short*) bmp565);
	return true;
}


/**
 * д����Ƶ��
 * @param data          ���� pcm16����
 * @param offset        ������ʼλ��
 * @param len           ���ݳ���
 * @param timestamp     ʱ���
 */
extern "C"
JNIEXPORT void JNICALL Java_com_feinno_avsdk_ffmpeg_MP4Writer_addAudio (JNIEnv* env, jobject,
		jshortArray arr, jint offset, jint len, jlong timestamp) {

	if (!gRuntime.isInited()) {
		logInt (-1);
		return;
	}

	int size = env->GetArrayLength(arr);
	if (mFIFOAudio == NULL || !mFIFOAudio->isOpened()) {
		return;
	}

	Frame* frame = mFIFOAudio->getEmpty(len * sizeof (short));
	if (frame != NULL) {
		env->GetShortArrayRegion(arr, offset, len, (short*) frame->data);
		frame->timestamp = len * sizeof (short);
		mFIFOAudio->addFull(frame);
	}
}




