/*
 * AudioFIFO.cpp
 *
 *  Created on: 2016��6��16��
 *      Author: Administrator
 */

#include "AudioFIFO.h"
#include "main.h"
#include "EnvRuntime.h"

AudioFIFO::AudioFIFO() {
}

AudioFIFO::~AudioFIFO() {
}


void AudioFIFO::onFrame (Frame* frame) {
	addAudio ( (unsigned short*) frame->data, (int) frame->timestamp / sizeof (short));
}
