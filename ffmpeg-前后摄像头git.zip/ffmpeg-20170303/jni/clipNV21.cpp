//
// Created by Administrator on 2016/5/24.
//
#include <stdio.h>
#include <stdlib.h>
#include "clipNV21.h"

//void YUV420spRotate90(byte *dst, const byte *src, int srcWidth, int srcHeight)
//{
//    static int nWidth = 0, nHeight = 0;
//    static int wh = 0;
//    static int uvHeight = 0;
//    if(srcWidth != nWidth || srcHeight != nHeight)
//    {
//        nWidth = srcWidth;
//        nHeight = srcHeight;
//        wh = srcWidth * srcHeight;
//        uvHeight = srcHeight >> 1;//uvHeight = height / 2
//    }
//
//    //��תY
//    int k = 0;
//    for(int i = 0; i < srcWidth; i++) {
//        int nPos = 0;
//        for(int j = 0; j < srcHeight; j++) {
//            dst[k] = src[nPos + i];
//            k++;
//            nPos += srcWidth;
//        }
//    }
//
//    for(int i = 0; i < srcWidth; i+=2){
//        int nPos = wh;
//        for(int j = 0; j < uvHeight; j++) {
//            dst[k] = src[nPos + i];
//            dst[k + 1] = src[nPos + i + 1];
//            k += 2;
//            nPos += srcWidth;
//        }
//    }
//    return;
//}
//
//void clipTargetRect(byte src[], byte dst[], int srcW, int srcH, int startW, int startH, int dstW, int dstH) {
//	if (src == null || dst == null || srcW < 1 || srcH < 1 || startW < 0
//		|| startH < 0 || dstW < 1 || dstH < 1 || startW + dstW > srcW
//		|| startH + dstH > srcH)
//		return;
//
//	int srcFrameSize = srcW * srcH;
//	int dstFrameSize = dstW * dstH;
//
//	for (int j = startH; j < startH + dstH; ++j) {
//		int jOffset = j - startH;
//		int srcUv = srcFrameSize + (j >> 1) * srcW;
//		int dstUv = dstFrameSize + (jOffset >> 1) * dstW;
//		for (int i = startW; i < startW + dstW; i += 2) {
//			int iOffset = i - startW;
//			dst[jOffset * dstW + iOffset] = src[j * srcW + i];
//			dst[jOffset * dstW + iOffset + 1] = src[j * srcW + i + 1];
//			if ((jOffset & 1)==0) {
//				dst[dstUv + iOffset] = src[srcUv + i];
//				dst[dstUv + iOffset + 1] = src[srcUv + i + 1];
//			}
//		}
//	}
//}

// ��ȡ���Զ���ת90
void clipTargetRect90(byte src[], byte dst[], int srcW, int srcH, int startW, int startH, int dstW, int dstH) {
	if (src == null || dst == null || srcW < 1 || srcH < 1 || startW < 0
		|| startH < 0 || dstW < 1 || dstH < 1 || startW + dstW > srcW
		|| startH + dstH > srcH)
		return;

	int srcFrameSize = srcW * srcH;
	int dstFrameSize = dstW * dstH;
	int jOffset, srcUv, i, iOffset, dstUv, ioffsetXh, jXsrcW, jOffsetRvt;

	for (int j = startH; j < startH + dstH; ++j) {
		jOffset = j - startH;
		jOffsetRvt = dstH - jOffset - 1;
		jXsrcW = j * srcW;
		srcUv = srcFrameSize + (jXsrcW >> 1);
		for (i = startW; i < startW + dstW; i += 2) {
			iOffset = i - startW;
			ioffsetXh = iOffset * dstH;
			dst[ioffsetXh + jOffsetRvt] = src[jXsrcW + i];
			dst[ioffsetXh + dstH + jOffsetRvt ] = src[jXsrcW + i + 1];

			dstUv = dstFrameSize + (ioffsetXh >> 1);
			if ((jOffset & 1)==0) {
				dst[dstUv + jOffsetRvt -1] = src[srcUv + i];
				dst[dstUv + jOffsetRvt ] = src[srcUv + i + 1];
			}
		}
	}
}


// ��ȡ���Զ���ת90
//void clipTargetRect902(byte src[], byte dst[], int srcW, int srcH, int startW, int startH, int dstW, int dstH) {
//	if (src == null || dst == null || srcW < 1 || srcH < 1 || startW < 0
//		|| startH < 0 || dstW < 1 || dstH < 1 || startW + dstW > srcW
//		|| startH + dstH > srcH)
//		return;
//
//	int srcFrameSize = srcW * srcH;
//	int dstFrameSize = dstW * dstH;
//
//	for (int j = startH; j < startH + dstH; ++j) {
//		int jOffset = j - startH;
//		int srcUv = srcFrameSize + (j >> 1) * srcW;
//		for (int i = startW; i < startW + dstW; i += 2) {
//			int iOffset = i - startW;
//			dst[iOffset * dstH + jOffset] = src[j * srcW + i];
//			dst[(iOffset + 1) * dstH + jOffset ] = src[j * srcW + i + 1];
//
//			int dstUv = dstFrameSize + (iOffset >> 1) * dstH;
//			if ((jOffset & 1)==0) {
//				dst[dstUv + jOffset] = src[srcUv + i];
//				dst[dstUv + jOffset + 1] = src[srcUv + i + 1];
//			}
//		}
//	}
//}
