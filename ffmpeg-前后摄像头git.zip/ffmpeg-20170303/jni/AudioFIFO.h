/*
 * AudioFIFO.h
 *
 *  Created on: 2016��6��16��
 *      Author: Administrator
 */

#ifndef AUDIOFIFO_H_
#define AUDIOFIFO_H_

#include "blockFIFO.h"

class AudioFIFO: public blockFIFO {
public:
	AudioFIFO();
	virtual ~AudioFIFO();
	virtual void  onFrame (Frame* frame);
};

#endif /* AUDIOFIFO_H_ */
