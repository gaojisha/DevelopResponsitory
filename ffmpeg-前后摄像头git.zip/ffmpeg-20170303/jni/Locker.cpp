/*
 * Locker.cpp
 *
 *  Created on: 2015��10��22��
 *      Author: Administrator
 */

#include "Locker.h"
#include <pthread.h>

namespace lkx {

Locker::Locker() {
	mObj = new pthread_mutex_t;

	pthread_mutexattr_t attr;
	pthread_mutexattr_init(&attr);
	pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE);
	pthread_mutex_init( (pthread_mutex_t*) mObj, &attr);
	pthread_mutexattr_destroy(&attr);
}

Locker::~Locker() {
	pthread_mutex_destroy((pthread_mutex_t*) mObj);
	delete (pthread_mutex_t*)mObj;
}

Lock::Lock(Locker* locker) {
	mLocker = locker;
	pthread_mutex_lock((pthread_mutex_t*) mLocker->mObj);
}

Lock::~Lock() {
	pthread_mutex_unlock((pthread_mutex_t*) mLocker->mObj);
}

Semaphore::Semaphore () {
	mObj = new pthread_cond_t;
	pthread_cond_init((pthread_cond_t*) mObj, 0);
}

Semaphore::~Semaphore () {
	pthread_cond_destroy((pthread_cond_t*) mObj);
	delete (pthread_cond_t*) mObj;
}

bool Semaphore::wait (Locker* locker) {
	pthread_cond_wait((pthread_cond_t*) mObj, (pthread_mutex_t*) locker->mObj);
}

void Semaphore::signal () {
	pthread_cond_signal((pthread_cond_t*) mObj);
}

} /* namespace lkx */
