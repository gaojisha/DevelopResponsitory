/*
 * EnvRuntime.h
 *
 *  Created on: 2016��5��25��
 *      Author: Administrator
 */

#ifndef ENVRUNTIME_H_
#define ENVRUNTIME_H_
#include <list>
#include <jni.h>
#include <android/log.h>
#include <stdio.h>
#include <stdlib.h>


#define LOGDEBUG

#ifdef LOGDEBUG
#define log(b) __android_log_print(ANDROID_LOG_ERROR, "NDK", "%s", (const char*)b)
#define logInt(b) __android_log_print(ANDROID_LOG_ERROR, "NDK", "%s:%d", __FUNCTION__, b)
#else
#define log(b)
#define logInt(b)
#endif


class EvnRuntime {



	jbyte* mFullVideoCache;					// ԭͼ����
	jint mFullVideoCacheSize;				// ԭͼ�����С

	jbyte* mClipedVideoCache;				// �ü���ͼƬ����
	jint mClipedVideoSize;					// �ü���ͼƬ�����С

	jshort* mImage565;						// ת��Ϊ������ʾ��img565���ͻ���
	jint mImage565Size;						// ת��Ϊ������ʾ��img565���ͻ����С

	jshort* mAudio;							// ����PCM16����
	jint mAudioSize;						// ����PCM16�����С

	bool mInited;

public:
	int mFrameRate;							// ffmpeg ֡�� 30
	int mVBitrate;							// ffmpeg ��Ƶ���� 400000
	int mVideoQuality;						// ��Ƶ���� 0 �� 5 �� 20 ��
                        //��ת�Ƕ�

	int mAudioBitrate;						// ��Ƶ���� 128000 �� 128000 �� 96000 ��
	int mAudioSampleRate;					// ��Ƶ������
	int mAudioChannels;						// ��Ƶ������
	int mAudioQuality;						// ��Ƶ���� 0 �� 5 �� 20 ��

public:


	int mSrcW, mSrcH, mDstW, mDstH,mRorate;			// mSrcW, mSrcH ԴͼƬ���ߣ�δ��ת��mDstW, mDstHĿ��ͼƬ���ߣ�����ת��
	int mClipW, mClipH;						// �ü���ͼƬ���ߣ�δ��ת��
	int mClipStartW, mClipStartH;			// �ü���ʼλ��
	int mClipImgSize;						// �ü���ͼƬռ���ڴ�Ĵ�С
	int m565ImgSize;						// �ü����л�Ϊbmp565��ռ���ڴ��С

public:
	EvnRuntime () {
		mFullVideoCache = NULL;
		mFullVideoCacheSize = 0;
		mInited = false;
	}

	void initCache (int srcw, int srch, int dstw, int dsth, int rorate) {
		if (mInited) {
			log ("cancel rep initCache");
			return;
		}
		mRorate =rorate;
		mSrcW = srcw;
		mSrcH = srch;
		mDstW = dstw;
		mDstH = dsth;
		mClipW = dsth;
		mClipH = dstw;
		mClipStartW = (mSrcW - mClipW) / 2;
		mClipStartH = (mSrcH - mClipH) / 2;
		mClipImgSize = mClipW * mClipH * 3 / 2;
		m565ImgSize = mClipW * mClipH;

		mInited = true;
		logSizes ();
		logInt (0);
	}

	void initFFMPEG (jint vFrameRate, jint vBitrate, jint vQuality,						// ��Ƶ����
			jint aBitrate, jint aSampleRate, jint aChannels, jint aQuality) {			// ��Ƶ����

		mFrameRate = vFrameRate;
		mVBitrate = vBitrate;
		mVideoQuality = vQuality;

		mAudioBitrate = aBitrate;
		mAudioSampleRate = aSampleRate;
		mAudioChannels = aChannels;
		mAudioQuality = aQuality;
	}

	void uninit () {
		mInited = false;
		logInt (0);

		free (mFullVideoCache);
		mFullVideoCache = NULL;
		mFullVideoCacheSize = 0;

		free (mClipedVideoCache);
		mClipedVideoCache = NULL;
		mClipedVideoSize = 0;

		free (mImage565);
		mImage565 = NULL;
		mImage565Size = 0;

		free (mAudio);
		mAudio = NULL;
		mAudioSize = 0;
	}

	bool isInited () {
		return mInited;
	}

	void logSizes () {
		char tmp[200] = { 0 };
		snprintf (tmp, sizeof (tmp) - 1, "mSrcW:%d mSrcH:%d mDstW:%d mDstH:%d mClipW:%d mClipH:%d mClipStartW:%d mClipStartH:%d mClipImgSize:%d m565ImgSize:%d",
				mSrcW, mSrcH, mDstW, mDstH, mClipW, mClipH, mClipStartW, mClipStartH, mClipImgSize, m565ImgSize);
		log (tmp);
	}

	jbyte* getFullVideoCache (jint size) {
		if (mFullVideoCacheSize >= size) {
			return mFullVideoCache;
		}
		logInt (size);
		free (mFullVideoCache);
		mFullVideoCache = (jbyte*) malloc (size);
		mFullVideoCacheSize = size;
		return mFullVideoCache;
	}

	jbyte* getClipedVideoCache (jint size) {
		if (mClipedVideoSize >= size) {
			return mClipedVideoCache;
		}
		logInt (size);
		free (mClipedVideoCache);
		mClipedVideoCache = (jbyte*) malloc (size);
		mClipedVideoSize = size;
		return mClipedVideoCache;
	}

	jshort* getImage565 (jint size) {
		if (mImage565Size >= size) {
			return mImage565;
		}
		logInt (size);
		free (mImage565);
		mImage565 = (jshort*) malloc (size * sizeof (jshort));
		mImage565Size = size;
		return mImage565;
	}

	jshort* getAudio (jint size) {
		if (mAudioSize >= size) {
			return mAudio;
		}
		logInt (size);
		free (mAudio);
		mAudio = (jshort*) malloc (size * sizeof (jshort));
		mAudioSize = size;
		return mAudio;
	}
};

extern EvnRuntime gRuntime;
extern  int  mmRorate;

#endif /* ENVRUNTIME_H_ */
