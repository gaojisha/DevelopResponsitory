/*
 * dump.cpp
 *
 *  Created on: 2016��5��27��
 *      Author: Administrator
 */




#include <signal.h>

#include <stdlib.h>
#include <jni.h>
#include <stdio.h>
#include "EnvRuntime.h"

static struct sigaction old_sa[NSIG];


void android_sigaction(int signal, siginfo_t *info, void *reserved)
{
	log ("sig error");
}

void InitCrashReport()
{
	log("InitCrashReport");

    // Try to catch crashes...
    struct sigaction handler;
    memset(&handler, 0, sizeof(struct sigaction));

    handler.sa_sigaction = android_sigaction;
    handler.sa_flags = SA_RESETHAND;

#define CATCHSIG(X) sigaction(X, &handler, &old_sa[X])
    CATCHSIG(SIGILL);
    CATCHSIG(SIGABRT);
    CATCHSIG(SIGBUS);
    CATCHSIG(SIGFPE);
    CATCHSIG(SIGSEGV);
    CATCHSIG(SIGSTKFLT);
    CATCHSIG(SIGPIPE);
}
