/*
 * blockFIFO.cpp
 *
 *  Created on: 2016��5��27��
 *      Author: Administrator
 */

#include "blockFIFO.h"
#include <stdlib.h>
#include <pthread.h>
#include "main.h"
#include "EnvRuntime.h"

#define MAX_ALLOC 5

blockFIFO::blockFIFO() {
	mRefCount = 0;
	mAlloced = 0;
	mOpened = false;
}

blockFIFO::~blockFIFO() {
	log ("destroy ~blockFIFO");
	clear ();
}

Frame* blockFIFO::getListEmpty () {
	Lock lock (&mEmptyLocker);
	if (mEmpty.empty()) {
		return NULL;
	}
	Frame* frame = mEmpty.front();
	mEmpty.pop_front();
	return frame;
}

Frame* blockFIFO::getEmpty (int size) {
	Frame* emp = getListEmpty ();
	if (emp != NULL) {
		return emp;
	}

	if (mAlloced > MAX_ALLOC) {
		log ("error getEmpty");
		return NULL;
	}

	mAlloced ++;
	Frame* f = new Frame ();
	f->size = size;
	f->data = (unsigned char*) malloc (size);
	return f;
}

void blockFIFO::addEmpty (Frame* frame) {
	Lock lock (&mEmptyLocker);
	mEmpty.push_back(frame);
}

void blockFIFO::addFull (Frame* frame) {
	Lock lock (&mFullLocker);
	mFull.push_back(frame);
	mFullSemo.signal();
}

Frame* blockFIFO::getFull () {
	Lock lock (&mFullLocker);
	if (!mOpened) {
		return NULL;
	}
	if (!mFull.empty()) {
		Frame* frame = mFull.front();
		mFull.pop_front();
		return frame;
	}

	mFullSemo.wait(&mFullLocker);

	if (!mOpened) {
		return NULL;
	}
	if (!mFull.empty()) {
		Frame* frame = mFull.front();
		mFull.pop_front();
		return frame;
	}
	return NULL;
}

void blockFIFO::open () {
	mOpened = true;
	mAlloced = 0;
	MP4addRef ();				// �̶߳�������Ҫ����MP4�����Զ�����������

	// �߳̽���ʱ�Զ��ͷ�
	addRef();
	pthread_t thread;

	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
	pthread_create(&thread, &attr, ThreadMain, this);
	pthread_attr_destroy(&attr);

}

void blockFIFO::close () {
	mOpened = false;
	mFullSemo.signal();
}

void blockFIFO::addRef () {
	mRefCount ++;
}

void blockFIFO::release () {
	mRefCount --;
	if (mRefCount == 0) {
		delete this;
	}
}

void blockFIFO::doWork () {
	Frame* frame;

	while (mOpened) {
		frame = getFull ();
		if (!mOpened || frame == NULL) {
			continue;
		}
		onFrame (frame);
		addEmpty (frame);
	}
}

void* blockFIFO::Entry() {
	doWork ();
	release ();			// �ͷŶ��Լ�������
	MP4release ();		// �ͷŶ�MP4������
}

void blockFIFO::onFrame (Frame* frame) {
	updateTimeStamp (frame->timestamp);
	addVideo ( (unsigned char*) frame->data);
}

void clearFrames (std::list<Frame*>& frames) {
	for (std::list<Frame*>::iterator i = frames.begin(); i!=frames.end(); i++) {
		free ((*i)->data);
		free (*i);
	}
	frames.clear();
}

void blockFIFO::clear () {
	clearFrames (mEmpty);
	clearFrames (mFull);
}





