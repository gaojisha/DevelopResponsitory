/*
 * clipNV21.h
 *
 *  Created on: 2016��5��24��
 *      Author: Administrator
 */

#ifndef CLIPNV21_H_
#define CLIPNV21_H_

typedef char byte;
#define null 0

// �и�ͼƬ
void clipTargetRect(byte src[], byte dst[], int srcW, int srcH, int startW, int startH, int dstW, int dstH);

// �и�ͬʱ��ת90��
void clipTargetRect90(byte src[], byte dst[], int srcW, int srcH, int startW, int startH, int dstW, int dstH);

// ��ת90��
void YUV420spRotate90(byte *dst, const byte *src, int srcWidth, int srcHeight);

#endif /* CLIPNV21_H_ */
