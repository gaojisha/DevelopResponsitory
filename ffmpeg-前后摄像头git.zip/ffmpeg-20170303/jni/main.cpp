/*
 * main.cpp
 *
 *  Created on: 2016��5��25��
 *      Author: Administrator
 */

extern "C" {
#include "libavcodec/avcodec.h"
#include "libavformat/avformat.h"
#include "libavutil/avutil.h"
#include "libavutil/audio_fifo.h"
#include "libswscale/swscale.h"
#include "libswresample/swresample.h"
}

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include "EnvRuntime.h"
#include "main.h"
#include "Locker.h"

#define FAIL_RETURN(func)		\
	logInt (__LINE__);			\
	if (!func) return false;

void log_callback_ndk (void *ptr, int level, const char *fmt, va_list vl) {
	char tmp[512] = { 0 };
	vsnprintf (tmp, 511, fmt, vl);
	log (tmp);
}

void initLog () {
	av_log_set_level (AV_LOG_DEBUG);
	av_log_set_callback (log_callback_ndk);
}

struct FFMPEGContext {
    AVFormatContext *oc;
    AVStream *video_st;
    AVStream *audio_st;

    AVFrame* picture;
    AVFrame* pre_cvt;

    AVFrame* audio_sec;
    AVPacket video_pkt;
    AVPacket audio_pkt;

    struct SwrContext* samples_convert_ctx;
    struct SwsContext* img_convert_ctx;

    bool inited;
    int lastFrameIndex;

    int refCount;						// ���߳��첽���ʣ�ֻ��ͨ�����ü����ر�
    lkx::Locker refLocker;				// �����ü������̱߳���

    unsigned char* video_fmtcvt_buf;	// ��Ƶ��ʽת��Buf
    int video_fmtcvt_buf_size;

    unsigned char* output_video_buf;	// ��Ƶѹ���������
    int output_video_buf_size;

    unsigned char* output_audio_buf;	// ��Ƶѹ���������
    int output_audio_buf_size;

    unsigned char* audio_resample_buf;	// ��Ƶ�ز����������
    int audio_resample_buf_size;		// ��Ƶ�ز�����������С
    int ou_position;					// ��Ƶ�ز���������浱ǰλ��

    FFMPEGContext () {
        oc = NULL;
        video_st = NULL;
        audio_st = NULL;
        picture = NULL;
        pre_cvt = NULL;
        audio_sec = NULL;
        samples_convert_ctx = NULL;
        img_convert_ctx = NULL;

        video_fmtcvt_buf = NULL;
        output_video_buf = NULL;
        output_audio_buf = NULL;
        audio_resample_buf = NULL;

        video_fmtcvt_buf_size = 0;
        output_video_buf_size = 0;
        output_audio_buf_size = 0;
        audio_resample_buf_size = 0;
        ou_position = 0;

    	inited = false;
    	lastFrameIndex = 0;
    }

    void freeContext () {
    	lastFrameIndex = 0;
    	for(int i = 0; i < (int)oc->nb_streams; i++) {
    		avcodec_close (oc->streams[i]->codec);
    	}

    	if (samples_convert_ctx != NULL) {
    		swr_free (&samples_convert_ctx);
    		samples_convert_ctx = NULL;
    	}

    	if (img_convert_ctx != NULL) {
    		sws_freeContext (img_convert_ctx);
    		img_convert_ctx = NULL;
    	}

    	if (audio_sec != NULL) {
    		av_frame_free (&audio_sec);
    		audio_sec = NULL;
    	}

    	if (picture != NULL) {
    		av_frame_free (&picture);
    		picture = NULL;
    	}

    	if (pre_cvt != NULL) {
    		av_frame_free (&pre_cvt);
    		pre_cvt = NULL;
    	}

    	avformat_close_input (&oc);

    	if (output_video_buf != NULL) {
    		av_free (output_video_buf);
    		output_video_buf = NULL;
    	}

    	if (output_audio_buf != NULL) {
    		av_free (output_audio_buf);
    		output_audio_buf = NULL;
    	}

    	if (audio_resample_buf != NULL) {
    		av_free (audio_resample_buf);
    		audio_resample_buf = NULL;
    	}

    	if (video_fmtcvt_buf != NULL) {
    		av_free (video_fmtcvt_buf);
    		video_fmtcvt_buf = NULL;
    	}

    	video_fmtcvt_buf_size = 0;
        output_video_buf_size = 0;
        output_audio_buf_size = 0;
        audio_resample_buf_size = 0;
        ou_position = 0;
    }
};

struct FFMPEGContext mContext;

bool initContext (const char* path) {
    avformat_alloc_output_context2 (&mContext.oc, NULL, NULL, path);
    if (!mContext.oc) {
        log("Memory error\n");
        return false;
    }
    return true;
}

bool initVideo () {
	enum AVCodecID codec_id = AV_CODEC_ID_MPEG4;

    AVCodec* codec = avcodec_find_encoder(codec_id);
    if (codec == NULL) {
    	log("MPEG4 CODEC NOT FOUND\n");
    	return false;
    }

    mContext.video_st = avformat_new_stream (mContext.oc, codec);
    if(!mContext.video_st) {
        log("could not alloc video stream\n");
		return false;
    }

	AVRational frame_rate = av_d2q (gRuntime.mFrameRate, 1001000);
	AVRational* supported_framerates = (AVRational*) codec->supported_framerates;
	if (supported_framerates != NULL) {
		int idx = av_find_nearest_q_idx(frame_rate, supported_framerates);
        frame_rate = supported_framerates[idx];
	}

	logInt (frame_rate);
	AVCodecContext* video_c = mContext.video_st->codec;

	video_c->codec_id = codec_id;
	video_c->codec_type = AVMEDIA_TYPE_VIDEO;
	video_c->bit_rate = gRuntime.mVBitrate;
	video_c->width = gRuntime.mDstW;
	video_c->height = gRuntime.mDstH;
	video_c->time_base = av_inv_q(frame_rate);

	if (gRuntime.mVideoQuality >= 0) {
		video_c->flags |= CODEC_FLAG_QSCALE | CODEC_FLAG_GLOBAL_HEADER;
		video_c->global_quality = (int) FF_QP2LAMBDA * gRuntime.mVideoQuality;
	}

	video_c->pix_fmt = AV_PIX_FMT_YUV420P;
	if (codec_id == AV_CODEC_ID_H264) {
		video_c->profile = FF_PROFILE_H264_BASELINE;
	}

	mContext.video_st->time_base = av_inv_q(frame_rate);
	log ("video_st->time_base:"); logInt (mContext.video_st->time_base.num);logInt (mContext.video_st->time_base.den);

	//video_c->me_range = 0;
	//video_c->max_qdiff = 3;
	//video_c->qmin = 10;
	//video_c->qmax = 50;			// �����ԣ���qmaxֵ����40ʱ��ͼƬ���������½���qmax=50��������ɫ��
	//video_c->qcompress = 0.6;
	//video_c->level = 11;

    return true;
}

bool openVideo () {
	AVCodecContext* video_c = mContext.video_st->codec;
	AVCodec* codec = (AVCodec*) video_c->codec;
	AVDictionary* dict = NULL;

	if (gRuntime.mVideoQuality >= 0) {
		char intValue[10] = { 0 };
		snprintf (intValue, sizeof (intValue) - 1, "%d", gRuntime.mVideoQuality);
		av_dict_set (&dict, "crf", intValue, 0);
	}

	if (avcodec_open2 (video_c, codec, &dict) < 0) {
		log ("open video codec error");
		return false;
	}

	log ("video_st->time_base:"); logInt (mContext.video_st->time_base.num);logInt (mContext.video_st->time_base.den);

    if (dict != NULL) {
    	av_dict_free (&dict);
    }
    return true;
}

bool initAudio () {
	enum AVCodecID codec_id = AV_CODEC_ID_AAC;
    AVCodec* codec = avcodec_find_encoder(codec_id);
    if (codec == NULL) {
        log("could not find audio codec\n");
		return false;
    }

    mContext.audio_st = avformat_new_stream (mContext.oc, codec);
    if (!mContext.audio_st) {
        log("could not alloc audio stream\n");
		return false;
    }

    if (!mContext.audio_st->codec) {
        log("could not alloc audio codec context\n");
		return false;
    }

    AVCodecContext* audio_c = mContext.audio_st->codec;
    audio_c->codec_id = codec_id;
    audio_c->codec_type = AVMEDIA_TYPE_AUDIO;
    audio_c->bit_rate = gRuntime.mAudioBitrate;
    audio_c->sample_rate = gRuntime.mAudioSampleRate;
    audio_c->channels = gRuntime.mAudioChannels;
    audio_c->channel_layout = av_get_default_channel_layout (gRuntime.mAudioChannels);

    audio_c->sample_fmt = AV_SAMPLE_FMT_NONE;
    AVSampleFormat* formats = (AVSampleFormat*) codec->sample_fmts;
    for (int i = 0; formats != NULL && formats[i] != AV_SAMPLE_FMT_NONE; i++) {
    	if (audio_c->sample_fmt == AV_SAMPLE_FMT_NONE) {
    		audio_c->sample_fmt = formats[i];
    	}
        if (formats[i] == AV_SAMPLE_FMT_S16) {
        	audio_c->sample_fmt = AV_SAMPLE_FMT_S16;
            break;
        }
    }

    log ("audio sample fmt:"); logInt (audio_c->sample_fmt);
    log ("audio sample rate:"); logInt (gRuntime.mAudioSampleRate);

    audio_c->time_base.num = 1;
    audio_c->time_base.den = gRuntime.mAudioSampleRate;

    mContext.audio_st->time_base.num = 1;
    mContext.audio_st->time_base.den = gRuntime.mAudioSampleRate;

    switch (audio_c->sample_fmt) {
    case AV_SAMPLE_FMT_U8:
    case AV_SAMPLE_FMT_U8P:
        audio_c->bits_per_raw_sample = 8;
        break;
    case AV_SAMPLE_FMT_S16:
    case AV_SAMPLE_FMT_S16P:
        audio_c->bits_per_raw_sample = 16;
        break;
    case AV_SAMPLE_FMT_S32:
    case AV_SAMPLE_FMT_S32P:
        audio_c->bits_per_raw_sample = 32;
        break;
    case AV_SAMPLE_FMT_FLT:
    case AV_SAMPLE_FMT_FLTP:
        audio_c->bits_per_raw_sample = 32;
        break;
    case AV_SAMPLE_FMT_DBL:
    case AV_SAMPLE_FMT_DBLP:
        audio_c->bits_per_raw_sample = 64;
        break;
    default:
    	log("audio fmt error");
        return false;
    }

    if (gRuntime.mAudioQuality >= 0) {
    	audio_c->flags |= CODEC_FLAG_QSCALE | CODEC_FLAG_GLOBAL_HEADER;
    	audio_c->global_quality = FF_QP2LAMBDA * gRuntime.mAudioQuality;
    }

    if (codec->capabilities & CODEC_CAP_EXPERIMENTAL) {
    	audio_c->strict_std_compliance = FF_COMPLIANCE_EXPERIMENTAL;
    }

    return true;
}

bool openAudio () {
	AVCodecContext* audio_c = mContext.audio_st->codec;
	AVCodec* codec = (AVCodec*) audio_c->codec;
	AVDictionary* dict = NULL;

	if (gRuntime.mAudioQuality >= 0) {
		char intValue[10] = { 0 };
		snprintf (intValue, sizeof (intValue) - 1, "%d", gRuntime.mAudioQuality);
		av_dict_set (&dict, "crf", intValue, 0);
	}

    if (!avcodec_open2 (audio_c, codec, &dict) < 0) {
    	log ("audio codec open failed");
    	return false;
    }

    if (dict != NULL) {
    	av_dict_free (&dict);
    }
    return true;
}

bool openMP4 (const char* path) {
	if (avio_open2 (&mContext.oc->pb, path, AVIO_FLAG_WRITE, NULL, NULL) < 0) {
		log ("open file failed");
		log (path);
		return false;
	}
	if (!mContext.oc->nb_streams) {
		log ("output file dose not contain any stream");
		return false;
	}
	if (avformat_write_header (mContext.oc, NULL) < 0) {
		log("Could not write header for output file\n");
		return false;
	}
	return true;
}

// ��ʼ������picture����
bool initPicture () {
	mContext.picture = av_frame_alloc();
	mContext.pre_cvt = av_frame_alloc();

	if (mContext.picture == NULL || mContext.pre_cvt == NULL) {
		log ("Could not allocate picture");
		return false;
	}
	logInt (0);
	mContext.picture->pts = 0;
	return true;
}

bool initVideoOutBuf () {
	mContext.output_video_buf_size =  mContext.video_st->codec->width *  mContext.video_st->codec->height * 2;
	mContext.output_video_buf = (unsigned char*) av_malloc (mContext.output_video_buf_size);
	if (mContext.output_video_buf == NULL) {
		log ("initVideoOutBuf error");
		return false;
	}
	return true;
}

bool initAudioOutBuf () {
	mContext.output_audio_buf_size = 256 * 1024;
	mContext.output_audio_buf = (unsigned char*) av_malloc (mContext.output_audio_buf_size);
	if (mContext.output_audio_buf == NULL) {
		log ("initAudioOutBuf error");
		return false;
	}

	int audio_input_frame_size = 0;
	if (mContext.audio_st->codec->frame_size <= 1) {
		audio_input_frame_size = FF_MIN_BUFFER_SIZE / mContext.audio_st->codec->channels;
	}
	else {
		audio_input_frame_size = mContext.audio_st->codec->frame_size;
	}

	mContext.audio_resample_buf_size = av_samples_get_buffer_size (NULL,
			mContext.audio_st->codec->channels, audio_input_frame_size,
			mContext.audio_st->codec->sample_fmt, 1);

	mContext.audio_resample_buf = (unsigned char*) av_malloc (mContext.audio_resample_buf_size);
	mContext.ou_position = 0;

	if (mContext.audio_resample_buf == NULL) {
		log ("audio_resample_buf alloc error");
		return false;
	}
	return true;
}

bool initAudioFrame () {
	mContext.audio_sec = av_frame_alloc();
	if (mContext.audio_sec == NULL) {
		log ("initAudioFrame error");
		return false;
	}
	mContext.audio_sec->pts = 0;
	return true;
}

bool initAudioSWR () {
	mContext.samples_convert_ctx = swr_alloc_set_opts (mContext.samples_convert_ctx,
			mContext.audio_st->codec->channel_layout, mContext.audio_st->codec->sample_fmt,
			mContext.audio_st->codec->sample_rate, av_get_default_channel_layout(gRuntime.mAudioChannels),
			AV_SAMPLE_FMT_S16P, gRuntime.mAudioSampleRate, 0, NULL);

	if (mContext.samples_convert_ctx == NULL) {
		log ("initAudioSWR alloc error");
		return false;
	}

	log ("sample_rate: "); logInt (mContext.audio_st->codec->sample_rate);

	if (swr_init (mContext.samples_convert_ctx) < 0) {
		log ("initAudioSWR init error");
		return false;
	}
	return true;
}

bool initVideoSWS () {
	mContext.img_convert_ctx = sws_getContext (gRuntime.mDstW, gRuntime.mDstH, AV_PIX_FMT_NV21,
			gRuntime.mDstW, gRuntime.mDstH, mContext.video_st->codec->pix_fmt,
			SWS_BILINEAR, NULL, NULL, NULL);
	if (mContext.img_convert_ctx == NULL) {
		log ("initVideoSWS error");
		return false;
	}

	mContext.video_fmtcvt_buf_size = avpicture_get_size(mContext.video_st->codec->pix_fmt, mContext.video_st->codec->width, mContext.video_st->codec->height);
	mContext.video_fmtcvt_buf = (unsigned char*) av_malloc (mContext.video_fmtcvt_buf_size);
	if (mContext.video_fmtcvt_buf == NULL) {
		log ("initVideoSWS buf error");
		return false;
	}

	return true;
}

bool createMP4File (const char* path) {
	initLog ();
    av_register_all ();
    FAIL_RETURN (initContext (path));

    FAIL_RETURN (initVideo ());
    FAIL_RETURN (initAudio ());
    FAIL_RETURN (openVideo());
    FAIL_RETURN (openAudio());

    FAIL_RETURN (openMP4 (path));
    FAIL_RETURN (initPicture());
    FAIL_RETURN (initVideoOutBuf());

    FAIL_RETURN (initAudioOutBuf());
    FAIL_RETURN (initAudioFrame());
    FAIL_RETURN (initAudioSWR());
    FAIL_RETURN (initVideoSWS());

    mContext.inited = true;
    MP4addRef ();

    logInt (0);
    return true;
}

bool addVideo (unsigned char* data) {
	if (!mContext.inited) {
		log ("not inited");
		return false;
	}

	// ת��ͼƬ��ʽ AV_PIX_FMT_NV21 --�� YUV420P
	avpicture_fill ((AVPicture*)mContext.pre_cvt, data, AV_PIX_FMT_NV21, gRuntime.mDstW, gRuntime.mDstH);
	avpicture_fill ((AVPicture*)mContext.picture, mContext.video_fmtcvt_buf, mContext.video_st->codec->pix_fmt, mContext.video_st->codec->width, mContext.video_st->codec->height);

	mContext.pre_cvt->format = AV_PIX_FMT_NV21;
	mContext.pre_cvt->width = gRuntime.mDstW;
	mContext.pre_cvt->height = gRuntime.mDstH;
	mContext.picture->format = mContext.video_st->codec->pix_fmt;
	mContext.picture->width = mContext.video_st->codec->width;
	mContext.picture->height = mContext.video_st->codec->height;
	sws_scale(mContext.img_convert_ctx, mContext.pre_cvt->data, mContext.pre_cvt->linesize,
	                        0, mContext.pre_cvt->height, mContext.picture->data, mContext.picture->linesize);

	mContext.picture->quality = mContext.video_st->codec->global_quality;
    av_init_packet(&mContext.video_pkt);

    mContext.video_pkt.data = mContext.output_video_buf;
    mContext.video_pkt.size = mContext.output_video_buf_size;

    int get_video_packet = 0;
    int ret = avcodec_encode_video2(mContext.video_st->codec, &mContext.video_pkt, mContext.picture, &get_video_packet);


    if (ret < 0) {
    	log ("error encode video");
    	return false;
    }

    mContext.picture->pts += 1;
    if (get_video_packet == 0) {
    	log ("error encode video empty");
    	return false;
    }

    if (mContext.video_pkt.pts != AV_NOPTS_VALUE) {
    	mContext.video_pkt.pts = av_rescale_q(mContext.video_pkt.pts,
    			mContext.video_st->codec->time_base, mContext.video_st->time_base);
    }
    if (mContext.video_pkt.dts != AV_NOPTS_VALUE) {
    	mContext.video_pkt.dts = av_rescale_q (mContext.video_pkt.dts,
    			mContext.video_st->codec->time_base, mContext.video_st->time_base);
    }

    mContext.video_pkt.stream_index = mContext.video_st->index;
    logInt (0);

    {
    lkx::Lock lock (&mContext.refLocker);
    if ((ret = av_interleaved_write_frame(mContext.oc, &mContext.video_pkt)) < 0) {
    	log ("error encode video write error");
    	return false;
    }
    }
    log ("==================use gRuntime.mRorate video");
int a=mmRorate;
if(a>0){
log ("=================gRuntime.mRorate ==111111111==== ");
}else{
	log ("=================gRuntime.mRorate ==end=000000000000000==== ");
}
	if(a>0){

    int rets = av_dict_set(&mContext.video_st->metadata,"rotate","180",0); //������ת�Ƕ�
       log ("==================use rotate video");
       if (rets < 0) {
           	log ("==================error encode video");
           	return false;
           }
    }
    return true;
}

int min (int n1, int n2) {
	return n1 < n2 ? n1 : n2;
}

bool encodeAudioFrame (AVFrame* frame) {
	av_init_packet (&mContext.audio_pkt);
	mContext.audio_pkt.data = mContext.output_audio_buf;
	mContext.audio_pkt.size = mContext.output_audio_buf_size;

	int got_audio_packet = 0;
	int ret = avcodec_encode_audio2(mContext.audio_st->codec, &mContext.audio_pkt, frame, &got_audio_packet);
	if (ret < 0) {
		log ("encodeFrame error");
		return false;
	}

	frame->pts += frame->nb_samples;
	if (got_audio_packet == 0) {
		log ("encodeFrame err no out");
		return false;
	}

	if (mContext.audio_pkt.pts != AV_NOPTS_VALUE) {
		mContext.audio_pkt.pts = av_rescale_q (mContext.audio_pkt.pts,
				mContext.audio_st->codec->time_base, mContext.audio_st->time_base);
	}
	if (mContext.audio_pkt.dts != AV_NOPTS_VALUE) {
		mContext.audio_pkt.dts = av_rescale_q (mContext.audio_pkt.dts,
				mContext.audio_st->codec->time_base, mContext.audio_st->time_base);
	}

	mContext.audio_pkt.flags |= AV_PKT_FLAG_KEY;
	mContext.audio_pkt.stream_index = mContext.audio_st->index;

	logInt (0);
	{
	lkx::Lock lock (&mContext.refLocker);
	if (av_interleaved_write_frame(mContext.oc, &mContext.audio_pkt) < 0) {
		log ("error write audio frame");
		return false;
	}
	}

	return true;
}

/**
 *@param  data		16λPCM��������
 *@param  size		short�������ݸ���
 */
bool addAudio (unsigned short* data, int size) {
	if (!mContext.inited) {
		log ("not inited audio");
		return false;
	}

	int inputDepths = 2;				// AV_SAMPLE_FMT_S16P	16λPCM
	int outputDepths = av_get_bytes_per_sample(mContext.audio_st->codec->sample_fmt);
	int in_position = 0;
	int inputCount;
	int outputCount;
	int swr_ret;

	AVCodecContext* audio_c = mContext.audio_st->codec;
	unsigned char* resamp_ou[1];
	unsigned char* resamp_in[1];
	unsigned char* audio = (unsigned char*) data;
	size *= sizeof (unsigned short);

	while (true) {
		inputCount = (size - in_position) / (inputDepths * gRuntime.mAudioChannels);
		outputCount = (mContext.audio_resample_buf_size - mContext.ou_position) / (mContext.audio_st->codec->channels * outputDepths);
		inputCount = min(inputCount, (outputCount * gRuntime.mAudioSampleRate + audio_c->sample_rate - 1) / audio_c->sample_rate);

		resamp_ou[0] = &mContext.audio_resample_buf[mContext.ou_position];		// �ز���ʱ������ԭ����λ�ü����ز���
		resamp_in[0] = &audio[in_position];

		swr_ret = swr_convert (mContext.samples_convert_ctx, (unsigned char**) resamp_ou, outputCount,
					(const uint8_t**) resamp_in, inputCount);

		if (swr_ret < 0) {
			log ("resample error");
			return false;
		}

		if (swr_ret == 0) {
			break;
		}

		in_position += inputCount * (inputDepths * gRuntime.mAudioChannels);
		mContext.ou_position += swr_ret * (mContext.audio_st->codec->channels * outputDepths);
		if (mContext.ou_position < mContext.audio_resample_buf_size) {
			continue;
		}

		mContext.audio_sec->nb_samples = audio_c->frame_size;
		resamp_ou[0] = &mContext.audio_resample_buf[0];								// ȡ����ʱ���ӿ�ʼȡ
		avcodec_fill_audio_frame (mContext.audio_sec, audio_c->channels, audio_c->sample_fmt,
				resamp_ou[0], mContext.audio_resample_buf_size, 0);

		for (int i=0; i<sizeof (resamp_ou) / sizeof (unsigned char*); i++) {
			mContext.audio_sec->data[i] = resamp_ou[0];
			mContext.audio_sec->linesize[i] = mContext.audio_resample_buf_size;
		}

		mContext.audio_sec->quality = audio_c->global_quality;
		encodeAudioFrame (mContext.audio_sec);

		// ׼����һ֡
		mContext.ou_position = 0;
	}

	return true;
}

bool closeMP4 () {
	if (!mContext.inited) {
		return true;
	}

	MP4release ();
	return true;
}

bool closeMP4Impl () {
	mContext.inited = false;
	if (mContext.oc == NULL) {
		log ("close rep");
		return false;
	}

	log ("close");
	{
	lkx::Lock lock (&mContext.refLocker);
	if (mContext.oc->pb != NULL) {
		av_interleaved_write_frame (mContext.oc, NULL);
		av_write_trailer(mContext.oc);
	}
	mContext.freeContext ();
	}
	return true;
 }

/**
 * ����picture��ʱ���
 */
void updateTimeStamp (long timestamp) {
	if (!mContext.inited) {
		return;
	}

    int frameNumber = (int) round(timestamp * gRuntime.mFrameRate / 1000000L);
    if (frameNumber <= mContext.lastFrameIndex) {
        frameNumber = mContext.lastFrameIndex + 1;
    }

    logInt (frameNumber);
    mContext.lastFrameIndex = frameNumber;
    mContext.picture->pts = frameNumber;
}

/**
 * ��������
 */
void MP4addRef () {
	lkx::Lock lock (&mContext.refLocker);
	mContext.refCount ++;
	logInt (mContext.refCount);
}

/**
 * �ͷ�����
 */
void MP4release () {
	lkx::Lock lock (&mContext.refLocker);
	mContext.refCount --;
	logInt (mContext.refCount);

	if (mContext.refCount == 0) {
		log ("destroy MP4");
		closeMP4Impl ();
	}
}









