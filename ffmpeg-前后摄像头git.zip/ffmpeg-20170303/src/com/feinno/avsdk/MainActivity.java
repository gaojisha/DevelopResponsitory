package com.feinno.avsdk;

import android.app.Activity;
import android.os.Bundle;
import android.view.SurfaceView;
import android.view.View;

import com.feinno.avsdk.ffmpeg.MP4Recorder;
import com.feinno.avsdk.ffmpeg.Trace;

public class MainActivity extends Activity implements View.OnClickListener {
    MP4Recorder mRecorder;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initCtrl ();
        initRecorder ();
    }
    
    protected void onDestroy () {
    	super.onDestroy();
    	mRecorder.onDestroy();
    	mRecorder = null;
    }

    void initCtrl () {
        findViewById(R.id.start).setOnClickListener(this);
        findViewById(R.id.stop).setOnClickListener(this);
        findViewById(R.id.cancel).setOnClickListener(this);
    }

    void initRecorder () {
        mRecorder = new MP4Recorder () {
            protected SurfaceView findSurfaceView() {
                return (SurfaceView) findViewById(R.id.sv);
            }
            protected Activity getContext() {
                return MainActivity.this;
            }
            protected float getWHRatio () {
            	return 1.77f;
            }
        };
        mRecorder.onCreate();
    }


    public void onClick (View v) {
        switch (v.getId()) {
            case R.id.start:
            	mRecorder.openMP4(10000, new MP4Recorder.MP4RecorderDelegate() {
					public void onTimeout(String path) {
						Trace.T(path);
						mRecorder.closeMP4(false);
					}
					public void onFinished(String path) {
						Trace.T(path);
					}
					public void onFailed(int err) {
						Trace.T();
					}
					public void onCanceled() {
						Trace.T();
					}
					public void onStarted() {
						Trace.T();
					}
				});
                break;
            case R.id.stop:
            	mRecorder.closeMP4(false);
                break;
            case R.id.cancel:
            	mRecorder.closeMP4(true);
                break;
        }
    }
}
