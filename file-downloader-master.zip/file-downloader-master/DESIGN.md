# file-downloader Design

**Download Process Map**
![image](https://github.com/wlfcolin/file-downloader/blob/master/design/Download Process Map.png)

**Classes Map**
![image](https://github.com/wlfcolin/file-downloader/blob/master/design/file-downloader classes map.png)