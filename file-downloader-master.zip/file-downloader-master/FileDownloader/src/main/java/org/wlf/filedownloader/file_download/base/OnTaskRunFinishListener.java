package org.wlf.filedownloader.file_download.base;

/**
 * @author wlf(Andy)
 * @datetime 2016-03-27 21:00 GMT+8
 * @email 411086563@qq.com
 */
public interface OnTaskRunFinishListener {

    /**
     * onTaskRunFinish
     */
    void onTaskRunFinish();
}
